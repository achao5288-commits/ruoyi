package cn.iocoder.txgy.module.mes.service.set.carbonreplace;

import cn.iocoder.txgy.framework.common.pojo.PageResult;
import cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace.vo.MesSetCarbonReplacePageReqVO;
import cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace.vo.MesSetCarbonReplaceSaveReqVO;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.carbonreplace.MesSetCarbonReplaceDO;

import jakarta.validation.Valid;

/**
 * MES 安全环保检测-换炭作业票 Service 接口
 *
 * @author OPENLAB BS
 */
public interface MesSetCarbonReplaceService {

    /**
     * 创建换炭作业票
     */
    Long createCarbonReplace(@Valid MesSetCarbonReplaceSaveReqVO createReqVO);

    /**
     * 更新换炭作业票
     */
    void updateCarbonReplace(@Valid MesSetCarbonReplaceSaveReqVO updateReqVO);

    /**
     * 删除换炭作业票
     */
    void deleteCarbonReplace(Long id);

    /**
     * 校验换炭作业票存在
     */
    void validateCarbonReplaceExists(Long id);

    /**
     * 获得换炭作业票
     */
    MesSetCarbonReplaceDO getCarbonReplace(Long id);

    /**
     * 获得换炭作业票分页
     */
    PageResult<MesSetCarbonReplaceDO> getCarbonReplacePage(MesSetCarbonReplacePageReqVO pageReqVO);

}
