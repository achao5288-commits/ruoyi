package cn.iocoder.txgy.module.mes.service.set.tracechain;

import cn.hutool.core.util.StrUtil;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.tracechain.MesSetSignRecordDO;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.tracechain.MesSetTraceChainDO;
import cn.iocoder.txgy.module.mes.dal.mysql.set.tracechain.MesSetSignRecordMapper;
import cn.iocoder.txgy.module.mes.dal.mysql.set.tracechain.MesSetTraceChainMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.time.LocalDateTime;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static cn.iocoder.txgy.framework.security.core.util.SecurityFrameworkUtils.getLoginUserId;
import static cn.iocoder.txgy.framework.security.core.util.SecurityFrameworkUtils.getLoginUserNickname;

/**
 * MES 安全环保检测-全程追溯链 Service 实现
 *
 * 正反向追溯均以"对象码"为节点游走：正向 = 对象自身节点 + 以其为 parent 的衍生对象节点逐层向下；
 * 反向 = 对象自身节点 + 其 parent_codes 对象的节点逐层向上。LIKE 预筛后按逗号精确拆分比对，
 * 避免批次码子串误匹配（如 B-12 误匹配 B-123）。
 *
 * @author OPENLAB BS
 */
@Service
@Validated
public class MesSetTraceChainServiceImpl implements MesSetTraceChainService {

    @Resource
    private MesSetTraceChainMapper traceChainMapper;

    @Resource
    private MesSetSignRecordMapper signRecordMapper;

    @Override
    public void appendNode(MesSetTraceChainDO node) {
        if (node.getOperateTime() == null) {
            node.setOperateTime(LocalDateTime.now());
        }
        traceChainMapper.insert(node);
    }

    @Override
    public void recordSign(MesSetSignRecordDO sign) {
        if (sign.getSignTime() == null) {
            sign.setSignTime(LocalDateTime.now());
        }
        if (StrUtil.isBlank(sign.getSignUser())) {
            sign.setSignUser(String.valueOf(getLoginUserId()));
        }
        if (StrUtil.isBlank(sign.getSignName())) {
            String nickname = getLoginUserNickname();
            sign.setSignName(StrUtil.isNotBlank(nickname) ? nickname : sign.getSignUser());
        }
        signRecordMapper.insert(sign);
    }

    @Override
    public TraceChainResult getTraceChain(String code) {
        TraceChainResult result = new TraceChainResult();
        result.setForward(buildForward(code));
        result.setBackward(buildBackward(code));
        return result;
    }

    @Override
    public List<MesSetSignRecordDO> getSignList(String bizType, String bizNo) {
        return signRecordMapper.selectByBiz(bizType, bizNo);
    }

    // ==================== 私有方法 ====================

    /**
     * 正向(跟去向)：对象自身节点 + 衍生对象(trace_code != code 但 parent_codes 含 code)节点，
     * 衍生对象入队继续向下，深度 ≤ MAX_DEPTH。
     */
    private List<MesSetTraceChainDO> buildForward(String code) {
        if (StrUtil.isBlank(code)) {
            return new ArrayList<>();
        }
        List<MesSetTraceChainDO> result = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        Deque<String> frontier = new ArrayDeque<>();
        visited.add(code);
        frontier.add(code);
        int depth = 0;
        while (!frontier.isEmpty() && depth < MAX_DEPTH) {
            depth++;
            Deque<String> next = new ArrayDeque<>();
            for (String cur : frontier) {
                result.addAll(traceChainMapper.selectByTraceCode(cur));
                // 衍生对象：parent_codes 精确含 cur 的节点 → 其 trace_code 为下游对象，入队继续向下
                for (MesSetTraceChainDO node : traceChainMapper.selectByParentCode(cur)) {
                    if (!containsParent(node.getParentCodes(), cur)) {
                        continue;
                    }
                    result.add(node);
                    if (StrUtil.isNotBlank(node.getTraceCode()) && visited.add(node.getTraceCode())) {
                        next.add(node.getTraceCode());
                    }
                }
            }
            frontier = next;
        }
        result.sort(java.util.Comparator.comparing(MesSetTraceChainDO::getOperateTime,
                java.util.Comparator.nullsLast(java.util.Comparator.naturalOrder())));
        return result;
    }

    /**
     * 反向(查来源)：对象自身节点 + parent_codes 指向的上游对象节点，逐层向上，深度 ≤ MAX_DEPTH。
     */
    private List<MesSetTraceChainDO> buildBackward(String code) {
        if (StrUtil.isBlank(code)) {
            return new ArrayList<>();
        }
        List<MesSetTraceChainDO> result = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        Deque<String> frontier = new ArrayDeque<>();
        visited.add(code);
        frontier.add(code);
        int depth = 0;
        while (!frontier.isEmpty() && depth < MAX_DEPTH) {
            depth++;
            Deque<String> next = new ArrayDeque<>();
            for (String cur : frontier) {
                for (MesSetTraceChainDO node : traceChainMapper.selectByTraceCode(cur)) {
                    result.add(node);
                    // 该节点的上游对象码入队继续向上
                    for (String parent : splitParents(node.getParentCodes())) {
                        if (visited.add(parent)) {
                            next.add(parent);
                        }
                    }
                }
            }
            frontier = next;
        }
        result.sort(java.util.Comparator.comparing(MesSetTraceChainDO::getOperateTime,
                java.util.Comparator.nullsLast(java.util.Comparator.naturalOrder())));
        return result;
    }

    /** parent_codes 逗号分隔精确拆分（过滤空白） */
    private List<String> splitParents(String parentCodes) {
        if (StrUtil.isBlank(parentCodes)) {
            return List.of();
        }
        return Arrays.stream(parentCodes.split("[,，]"))
                .map(String::trim)
                .filter(StrUtil::isNotBlank)
                .toList();
    }

    /** parent_codes 是否精确包含某上游码（防子串误匹配） */
    private boolean containsParent(String parentCodes, String code) {
        return splitParents(parentCodes).contains(code);
    }

}
