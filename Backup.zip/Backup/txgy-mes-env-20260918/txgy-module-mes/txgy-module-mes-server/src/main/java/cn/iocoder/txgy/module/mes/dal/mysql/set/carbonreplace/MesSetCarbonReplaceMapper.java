package cn.iocoder.txgy.module.mes.dal.mysql.set.carbonreplace;

import cn.iocoder.txgy.framework.common.pojo.PageResult;
import cn.iocoder.txgy.framework.mybatis.core.mapper.BaseMapperX;
import cn.iocoder.txgy.framework.mybatis.core.query.LambdaQueryWrapperX;
import cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace.vo.MesSetCarbonReplacePageReqVO;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.carbonreplace.MesSetCarbonReplaceDO;
import org.apache.ibatis.annotations.Mapper;

/**
 * MES 安全环保检测-换炭作业票 Mapper
 *
 * @author OPENLAB BS
 */
@Mapper
public interface MesSetCarbonReplaceMapper extends BaseMapperX<MesSetCarbonReplaceDO> {

    default PageResult<MesSetCarbonReplaceDO> selectPage(MesSetCarbonReplacePageReqVO reqVO) {
        return selectPage(reqVO, new LambdaQueryWrapperX<MesSetCarbonReplaceDO>()
                .eqIfPresent(MesSetCarbonReplaceDO::getCode, reqVO.getCode())
                .eqIfPresent(MesSetCarbonReplaceDO::getFacilityId, reqVO.getFacilityId())
                .eqIfPresent(MesSetCarbonReplaceDO::getStatus, reqVO.getStatus())
                .orderByDesc(MesSetCarbonReplaceDO::getId));
    }

    default MesSetCarbonReplaceDO selectByCode(String code) {
        return selectOne(MesSetCarbonReplaceDO::getCode, code);
    }

}
