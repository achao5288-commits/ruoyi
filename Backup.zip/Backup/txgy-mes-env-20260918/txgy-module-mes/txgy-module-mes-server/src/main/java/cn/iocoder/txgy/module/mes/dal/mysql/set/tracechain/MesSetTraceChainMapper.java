package cn.iocoder.txgy.module.mes.dal.mysql.set.tracechain;

import cn.iocoder.txgy.framework.mybatis.core.mapper.BaseMapperX;
import cn.iocoder.txgy.framework.mybatis.core.query.LambdaQueryWrapperX;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.tracechain.MesSetTraceChainDO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * MES 安全环保检测-全程追溯链节点 Mapper
 *
 * @author OPENLAB BS
 */
@Mapper
public interface MesSetTraceChainMapper extends BaseMapperX<MesSetTraceChainDO> {

    /** 某对象码的全部节点，按 id 升序 = 时间正序（对象码上的完整履历） */
    default List<MesSetTraceChainDO> selectByTraceCode(String traceCode) {
        return selectList(new LambdaQueryWrapperX<MesSetTraceChainDO>()
                .eq(MesSetTraceChainDO::getTraceCode, traceCode)
                .orderByAsc(MesSetTraceChainDO::getId));
    }

    /**
     * 以某对象码为上游来源(parent_codes 含该码)的节点（衍生对象，如拆分/返工/危废父子）。
     * parent_codes 逗号分隔，LIKE 预筛后由 Service 精确拆分比对，避免批次码子串误匹配。
     */
    default List<MesSetTraceChainDO> selectByParentCode(String parentCode) {
        return selectList(new LambdaQueryWrapperX<MesSetTraceChainDO>()
                .like(MesSetTraceChainDO::getParentCodes, parentCode)
                .orderByAsc(MesSetTraceChainDO::getId));
    }

    /** 某单据(type+no)产生的全部节点 */
    default List<MesSetTraceChainDO> selectByBiz(String bizType, String bizNo) {
        return selectList(new LambdaQueryWrapperX<MesSetTraceChainDO>()
                .eq(MesSetTraceChainDO::getBizType, bizType)
                .eq(MesSetTraceChainDO::getBizNo, bizNo)
                .orderByAsc(MesSetTraceChainDO::getId));
    }

}
