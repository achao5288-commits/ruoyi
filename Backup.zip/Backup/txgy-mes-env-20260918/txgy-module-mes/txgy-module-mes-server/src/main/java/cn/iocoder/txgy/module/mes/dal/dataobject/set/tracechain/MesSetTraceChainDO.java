package cn.iocoder.txgy.module.mes.dal.dataobject.set.tracechain;

import cn.iocoder.txgy.framework.mybatis.core.dataobject.BaseDO;
import com.baomidou.mybatisplus.annotation.KeySequence;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * MES 安全环保检测-全程追溯链节点 DO
 *
 * "业务动一次，链路长一节"：由现有业务动作（入库/领用/判定/处置/成品/出库）完成后自动写入，
 * 只增不改；trace_code 为节点对象码（批次码为主，无批次的判定/处置用记录号），parent_codes
 * 记录上游对象码（拆分/合并/返工/危废父子关联时回填），正反向追溯沿这两个字段游走。
 *
 * @author OPENLAB BS
 */
@TableName("mes_set_trace_chain")
@KeySequence("mes_set_trace_chain_seq") // 用于 Oracle、PostgreSQL、Kingbase、DB2、H2 数据库的主键自增。如果是 MySQL 等数据库，可不写。
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MesSetTraceChainDO extends BaseDO {

    /**
     * 编号
     */
    @TableId
    private Long id;
    /**
     * 本节点对象码（批次码/记录号）
     */
    private String traceCode;
    /**
     * 上游来源码，逗号分隔（拆分/合并/返工时回填）
     */
    private String parentCodes;
    /**
     * 环节：PURCHASE_INBOUND(采购入库)/MATERIAL_ISSUE(生产领用)/WASTE_INTERMEDIATE(中间废弃物)/FINISHED_PRODUCT(成品)/SALES_OUTBOUND(销售出库)/DISPOSITION(处置流转)
     */
    private String nodeStage;
    /**
     * 危害类型：NORMAL(正常)/POLLUTED(有污染受控)/HAZ_WASTE(危废)
     */
    private String hazardType;
    /**
     * 批次状态快照（在库/隔离/已领用/已出库等）
     */
    private String batchStatus;
    /**
     * 物料/产品编码
     */
    private String itemCode;
    /**
     * 物料/产品名称
     */
    private String itemName;
    /**
     * 规格
     */
    private String itemSpec;
    /**
     * 批次号
     */
    private String batchNo;
    /**
     * 数量
     */
    private BigDecimal quantity;
    /**
     * 单据类型：POLLUTION_CHECK(判定)/POLLUTION_LEDGER(台账)/WM_ITEM_RECEIPT(入库单)/WM_PRODUCT_ISSUE(领料单)/WM_PRODUCT_RECEIPT(成品入库单)/WM_PRODUCT_SALES(出库单)
     */
    private String bizType;
    /**
     * 关联单据号
     */
    private String bizNo;
    /**
     * 去向/库位
     */
    private String location;
    /**
     * 操作人
     */
    private String operator;
    /**
     * 复核人
     */
    private String reviewer;
    /**
     * 审批人
     */
    private String approver;
    /**
     * 操作时间
     */
    private LocalDateTime operateTime;
    /**
     * 备注
     */
    private String remark;

}
