package cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Schema(description = "管理后台 - MES 安全环保检测-治污设施台账 Response VO")
@Data
public class MesSetFacilityRespVO {

    @Schema(description = "编号", example = "1")
    private Long id;

    @Schema(description = "设施编号")
    private String code;

    @Schema(description = "设施名称")
    private String name;

    @Schema(description = "设施类型")
    private String facilityType;

    @Schema(description = "关联设备编号", example = "1")
    private Long machineryId;

    @Schema(description = "所在车间编号", example = "1")
    private Long workshopId;

    @Schema(description = "对应排放口编号")
    private String outletCode;

    @Schema(description = "设计处理能力")
    private String designCapacity;

    @Schema(description = "活性炭填充量(kg)")
    private BigDecimal carbonLoad;

    @Schema(description = "活性炭更换周期(天)")
    private Integer carbonCycleDays;

    @Schema(description = "最近一次换炭时间")
    private LocalDateTime lastCarbonTime;

    @Schema(description = "废活性炭去向")
    private String wasteLocation;

    @Schema(description = "运行状态")
    private String status;

    @Schema(description = "设施照片 URL")
    private String photoUrl;

    @Schema(description = "备注")
    private String remark;

    @Schema(description = "创建时间")
    private LocalDateTime createTime;

}
