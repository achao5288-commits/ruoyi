package cn.iocoder.txgy.module.mes.service.set.facility;

import cn.iocoder.txgy.framework.common.pojo.PageResult;
import cn.iocoder.txgy.framework.common.util.object.BeanUtils;
import cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo.MesSetFacilityPageReqVO;
import cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo.MesSetFacilitySaveReqVO;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.facility.MesSetFacilityDO;
import cn.iocoder.txgy.module.mes.dal.mysql.set.facility.MesSetFacilityMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import static cn.iocoder.txgy.framework.common.exception.util.ServiceExceptionUtil.exception;
import static cn.iocoder.txgy.module.mes.enums.ErrorCodeConstants.SET_FACILITY_NO_DUPLICATE;
import static cn.iocoder.txgy.module.mes.enums.ErrorCodeConstants.SET_FACILITY_NOT_EXISTS;

/**
 * MES 安全环保检测-治污设施台账 Service 实现类
 *
 * @author OPENLAB BS
 */
@Service
@Validated
public class MesSetFacilityServiceImpl implements MesSetFacilityService {

    @Resource
    private MesSetFacilityMapper facilityMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long createFacility(MesSetFacilitySaveReqVO createReqVO) {
        // 1. 校验设施编号唯一
        validateCodeUnique(null, createReqVO.getCode());
        // 2. 插入记录
        MesSetFacilityDO facility = BeanUtils.toBean(createReqVO, MesSetFacilityDO.class);
        facilityMapper.insert(facility);
        return facility.getId();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateFacility(MesSetFacilitySaveReqVO updateReqVO) {
        // 1. 校验存在 + 设施编号唯一
        validateFacilityExists(updateReqVO.getId());
        validateCodeUnique(updateReqVO.getId(), updateReqVO.getCode());
        // 2. 更新
        MesSetFacilityDO updateObj = BeanUtils.toBean(updateReqVO, MesSetFacilityDO.class);
        facilityMapper.updateById(updateObj);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteFacility(Long id) {
        // 1. 校验存在
        validateFacilityExists(id);
        // 2. 删除
        facilityMapper.deleteById(id);
    }

    @Override
    public void validateFacilityExists(Long id) {
        if (facilityMapper.selectById(id) == null) {
            throw exception(SET_FACILITY_NOT_EXISTS);
        }
    }

    @Override
    public MesSetFacilityDO getFacility(Long id) {
        return facilityMapper.selectById(id);
    }

    @Override
    public PageResult<MesSetFacilityDO> getFacilityPage(MesSetFacilityPageReqVO pageReqVO) {
        return facilityMapper.selectPage(pageReqVO);
    }

    // ==================== 校验方法 ====================

    /**
     * 校验设施编号是否唯一（更新时排除自身）
     *
     * @param id 编号
     * @param code 设施编号
     */
    private void validateCodeUnique(Long id, String code) {
        MesSetFacilityDO exist = facilityMapper.selectByCode(code);
        if (exist != null && !exist.getId().equals(id)) {
            throw exception(SET_FACILITY_NO_DUPLICATE);
        }
    }

}
