package cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo;

import cn.iocoder.txgy.framework.common.pojo.PageParam;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Schema(description = "管理后台 - MES 安全环保检测-治污设施台账 分页 Request VO")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class MesSetFacilityPageReqVO extends PageParam {

    @Schema(description = "设施编号", example = "FAC-001")
    private String code;

    @Schema(description = "设施名称", example = "活性炭吸附")
    private String name;

    @Schema(description = "设施类型", example = "ACTIVATED_CARBON")
    private String facilityType;

    @Schema(description = "运行状态", example = "RUNNING")
    private String status;

}
