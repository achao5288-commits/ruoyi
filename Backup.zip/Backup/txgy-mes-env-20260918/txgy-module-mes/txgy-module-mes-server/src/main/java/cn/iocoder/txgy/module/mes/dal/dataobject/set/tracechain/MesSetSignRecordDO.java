package cn.iocoder.txgy.module.mes.dal.dataobject.set.tracechain;

import cn.iocoder.txgy.framework.mybatis.core.dataobject.BaseDO;
import com.baomidou.mybatisplus.annotation.KeySequence;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.time.LocalDateTime;

/**
 * MES 安全环保检测-环环签字记录 DO
 *
 * 只增不改不删：无 update/delete 业务入口，与操作日志、追溯链多向印证；
 * 签字角色 OPERATOR/REVIEWER/APPROVER/GATE/EXTERNAL（外部签字本期预留，联单对接后回填）。
 *
 * @author OPENLAB BS
 */
@TableName("mes_set_sign_record")
@KeySequence("mes_set_sign_record_seq") // 用于 Oracle、PostgreSQL、Kingbase、DB2、H2 数据库的主键自增。如果是 MySQL 等数据库，可不写。
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MesSetSignRecordDO extends BaseDO {

    /** 签字角色：操作 */
    public static final String SIGN_ROLE_OPERATOR = "OPERATOR";
    /** 签字角色：复核 */
    public static final String SIGN_ROLE_REVIEWER = "REVIEWER";
    /** 签字角色：审批 */
    public static final String SIGN_ROLE_APPROVER = "APPROVER";
    /** 签字角色：门卫/出厂核验 */
    public static final String SIGN_ROLE_GATE = "GATE";
    /** 签字角色：外部（运输/处置单位，国家联单确认） */
    public static final String SIGN_ROLE_EXTERNAL = "EXTERNAL";

    /**
     * 编号
     */
    @TableId
    private Long id;
    /**
     * 单据类型
     */
    private String bizType;
    /**
     * 单据号
     */
    private String bizNo;
    /**
     * 环节
     */
    private String nodeStage;
    /**
     * 签字角色：OPERATOR(操作)/REVIEWER(复核)/APPROVER(审批)/GATE(门卫)/EXTERNAL(外部)
     */
    private String signRole;
    /**
     * 签字人账号
     */
    private String signUser;
    /**
     * 签字人姓名
     */
    private String signName;
    /**
     * 手写签名图片地址
     */
    private String signImg;
    /**
     * 签字时间
     */
    private LocalDateTime signTime;
    /**
     * 签字地点(GPS/库位)
     */
    private String signLocation;
    /**
     * 签字/审批意见
     */
    private String signOpinion;

}
