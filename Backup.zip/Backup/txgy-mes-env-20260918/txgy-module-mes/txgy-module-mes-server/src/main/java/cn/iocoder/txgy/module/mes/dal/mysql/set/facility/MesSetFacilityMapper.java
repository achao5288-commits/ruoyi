package cn.iocoder.txgy.module.mes.dal.mysql.set.facility;

import cn.iocoder.txgy.framework.common.pojo.PageResult;
import cn.iocoder.txgy.framework.mybatis.core.mapper.BaseMapperX;
import cn.iocoder.txgy.framework.mybatis.core.query.LambdaQueryWrapperX;
import cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo.MesSetFacilityPageReqVO;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.facility.MesSetFacilityDO;
import org.apache.ibatis.annotations.Mapper;

/**
 * MES 安全环保检测-治污设施台账 Mapper
 *
 * @author OPENLAB BS
 */
@Mapper
public interface MesSetFacilityMapper extends BaseMapperX<MesSetFacilityDO> {

    default PageResult<MesSetFacilityDO> selectPage(MesSetFacilityPageReqVO reqVO) {
        return selectPage(reqVO, new LambdaQueryWrapperX<MesSetFacilityDO>()
                .eqIfPresent(MesSetFacilityDO::getCode, reqVO.getCode())
                .likeIfPresent(MesSetFacilityDO::getName, reqVO.getName())
                .eqIfPresent(MesSetFacilityDO::getFacilityType, reqVO.getFacilityType())
                .eqIfPresent(MesSetFacilityDO::getStatus, reqVO.getStatus())
                .orderByDesc(MesSetFacilityDO::getId));
    }

    default MesSetFacilityDO selectByCode(String code) {
        return selectOne(MesSetFacilityDO::getCode, code);
    }

}
