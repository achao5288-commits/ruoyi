package cn.iocoder.txgy.module.mes.service.set.carbonreplace;

import cn.iocoder.txgy.framework.common.pojo.PageResult;
import cn.iocoder.txgy.framework.common.util.object.BeanUtils;
import cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace.vo.MesSetCarbonReplacePageReqVO;
import cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace.vo.MesSetCarbonReplaceSaveReqVO;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.carbonreplace.MesSetCarbonReplaceDO;
import cn.iocoder.txgy.module.mes.dal.mysql.set.carbonreplace.MesSetCarbonReplaceMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import static cn.iocoder.txgy.framework.common.exception.util.ServiceExceptionUtil.exception;
import static cn.iocoder.txgy.module.mes.enums.ErrorCodeConstants.SET_FACILITY_REPLACE_NO_DUPLICATE;
import static cn.iocoder.txgy.module.mes.enums.ErrorCodeConstants.SET_FACILITY_REPLACE_NOT_EXISTS;

/**
 * MES 安全环保检测-换炭作业票 Service 实现类
 *
 * @author OPENLAB BS
 */
@Service
@Validated
public class MesSetCarbonReplaceServiceImpl implements MesSetCarbonReplaceService {

    @Resource
    private MesSetCarbonReplaceMapper carbonReplaceMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long createCarbonReplace(MesSetCarbonReplaceSaveReqVO createReqVO) {
        // 1. 校验作业票编号唯一
        validateCodeUnique(null, createReqVO.getCode());
        // 2. 插入记录
        MesSetCarbonReplaceDO carbonReplace = BeanUtils.toBean(createReqVO, MesSetCarbonReplaceDO.class);
        carbonReplaceMapper.insert(carbonReplace);
        return carbonReplace.getId();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateCarbonReplace(MesSetCarbonReplaceSaveReqVO updateReqVO) {
        // 1. 校验存在 + 作业票编号唯一
        validateCarbonReplaceExists(updateReqVO.getId());
        validateCodeUnique(updateReqVO.getId(), updateReqVO.getCode());
        // 2. 更新
        MesSetCarbonReplaceDO updateObj = BeanUtils.toBean(updateReqVO, MesSetCarbonReplaceDO.class);
        carbonReplaceMapper.updateById(updateObj);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteCarbonReplace(Long id) {
        // 1. 校验存在
        validateCarbonReplaceExists(id);
        // 2. 删除
        carbonReplaceMapper.deleteById(id);
    }

    @Override
    public void validateCarbonReplaceExists(Long id) {
        if (carbonReplaceMapper.selectById(id) == null) {
            throw exception(SET_FACILITY_REPLACE_NOT_EXISTS);
        }
    }

    @Override
    public MesSetCarbonReplaceDO getCarbonReplace(Long id) {
        return carbonReplaceMapper.selectById(id);
    }

    @Override
    public PageResult<MesSetCarbonReplaceDO> getCarbonReplacePage(MesSetCarbonReplacePageReqVO pageReqVO) {
        return carbonReplaceMapper.selectPage(pageReqVO);
    }

    // ==================== 校验方法 ====================

    /**
     * 校验作业票编号是否唯一（更新时排除自身）
     *
     * @param id 编号
     * @param code 作业票编号
     */
    private void validateCodeUnique(Long id, String code) {
        MesSetCarbonReplaceDO exist = carbonReplaceMapper.selectByCode(code);
        if (exist != null && !exist.getId().equals(id)) {
            throw exception(SET_FACILITY_REPLACE_NO_DUPLICATE);
        }
    }

}
