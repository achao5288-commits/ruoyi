package cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Schema(description = "管理后台 - MES 安全环保检测-换炭作业票 Response VO")
@Data
public class MesSetCarbonReplaceRespVO {

    @Schema(description = "编号", example = "1")
    private Long id;

    @Schema(description = "作业票编号")
    private String code;

    @Schema(description = "治污设施编号", example = "1")
    private Long facilityId;

    @Schema(description = "换炭时间")
    private LocalDateTime replaceTime;

    @Schema(description = "旧炭重量(kg)")
    private BigDecimal oldCarbonWeight;

    @Schema(description = "新炭批次号")
    private String newCarbonBatchNo;

    @Schema(description = "新炭填充量(kg)")
    private BigDecimal newCarbonLoad;

    @Schema(description = "碘值")
    private BigDecimal iodineValue;

    @Schema(description = "现场照片 URLs")
    private String photoUrls;

    @Schema(description = "称重数据来源")
    private String weightSource;

    @Schema(description = "废活性炭去向")
    private String wasteLocation;

    @Schema(description = "状态")
    private String status;

    @Schema(description = "操作人")
    private String operator;

    @Schema(description = "备注")
    private String remark;

    @Schema(description = "创建时间")
    private LocalDateTime createTime;

}
