package cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Schema(description = "管理后台 - MES 安全环保检测-治污设施台账 新增/修改 Request VO")
@Data
public class MesSetFacilitySaveReqVO {

    @Schema(description = "编号", example = "1")
    private Long id;

    @Schema(description = "设施编号", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotEmpty(message = "设施编号不能为空")
    private String code;

    @Schema(description = "设施名称", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotEmpty(message = "设施名称不能为空")
    private String name;

    @Schema(description = "设施类型", example = "ACTIVATED_CARBON")
    private String facilityType;

    @Schema(description = "关联设备编号", example = "1")
    private Long machineryId;

    @Schema(description = "所在车间编号", example = "1")
    private Long workshopId;

    @Schema(description = "对应排放口编号")
    private String outletCode;

    @Schema(description = "设计处理能力")
    private String designCapacity;

    @Schema(description = "活性炭填充量(kg)", example = "100.00")
    private BigDecimal carbonLoad;

    @Schema(description = "活性炭更换周期(天)", example = "90")
    private Integer carbonCycleDays;

    @Schema(description = "最近一次换炭时间")
    private LocalDateTime lastCarbonTime;

    @Schema(description = "废活性炭去向")
    private String wasteLocation;

    @Schema(description = "运行状态", example = "RUNNING")
    private String status;

    @Schema(description = "设施照片 URL")
    private String photoUrl;

    @Schema(description = "备注")
    private String remark;

}
