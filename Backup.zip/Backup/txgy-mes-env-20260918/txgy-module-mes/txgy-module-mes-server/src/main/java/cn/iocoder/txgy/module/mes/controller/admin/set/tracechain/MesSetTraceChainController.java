package cn.iocoder.txgy.module.mes.controller.admin.set.tracechain;

import cn.iocoder.txgy.framework.common.pojo.CommonResult;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.tracechain.MesSetSignRecordDO;
import cn.iocoder.txgy.module.mes.service.set.tracechain.MesSetTraceChainService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static cn.iocoder.txgy.framework.common.pojo.CommonResult.success;

@Tag(name = "管理后台 - MES 安全环保检测-全程追溯")
@RestController
@RequestMapping("/mes/safety-env/trace-chain")
@Validated
public class MesSetTraceChainController {

    @Resource
    private MesSetTraceChainService traceChainService;

    @GetMapping("/trace")
    @Operation(summary = "一码到底追溯(正向跟去向 + 反向查来源，节点按操作时间升序)")
    @Parameter(name = "code", description = "对象码(批次码/记录号)", required = true, example = "B20260917001")
    @PreAuthorize("@ss.hasPermission('mes:set-trace:query')")
    public CommonResult<MesSetTraceChainService.TraceChainResult> getTraceChain(
            @RequestParam("code") String code) {
        return success(traceChainService.getTraceChain(code));
    }

    @GetMapping("/signs")
    @Operation(summary = "获得单据签字记录(操作/复核/审批，只增不改)")
    @Parameter(name = "bizType", description = "单据类型", required = true, example = "POLLUTION_CHECK")
    @Parameter(name = "bizNo", description = "单据号", required = true, example = "PC-20260917-001")
    @PreAuthorize("@ss.hasPermission('mes:set-trace:query')")
    public CommonResult<List<MesSetSignRecordDO>> getSignList(@RequestParam("bizType") String bizType,
                                                              @RequestParam("bizNo") String bizNo) {
        return success(traceChainService.getSignList(bizType, bizNo));
    }

}
