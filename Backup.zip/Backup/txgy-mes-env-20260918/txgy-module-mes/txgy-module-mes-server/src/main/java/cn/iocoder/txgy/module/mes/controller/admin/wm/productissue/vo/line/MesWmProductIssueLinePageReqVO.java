package cn.iocoder.txgy.module.mes.controller.admin.wm.productissue.vo.line;

import cn.iocoder.txgy.framework.common.pojo.PageParam;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Schema(description = "管理后台 - MES 领料出库单行分页 Request VO")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class MesWmProductIssueLinePageReqVO extends PageParam {

    @Schema(description = "领料单编号；留空则跨单查询（配合 itemId 使用）", example = "1")
    private Long issueId;

    @Schema(description = "物料编号；按物料反查含该物料的领料单行", example = "1")
    private Long itemId;

}
