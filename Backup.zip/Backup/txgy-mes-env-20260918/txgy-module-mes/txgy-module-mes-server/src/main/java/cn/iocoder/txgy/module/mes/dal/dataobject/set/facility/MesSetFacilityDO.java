package cn.iocoder.txgy.module.mes.dal.dataobject.set.facility;

import cn.iocoder.txgy.framework.mybatis.core.dataobject.BaseDO;
import com.baomidou.mybatisplus.annotation.KeySequence;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * MES 安全环保检测-治污设施台账 DO
 *
 * @author OPENLAB BS
 */
@TableName("mes_set_facility")
@KeySequence("mes_set_facility_seq")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MesSetFacilityDO extends BaseDO {

    /**
     * 编号
     */
    @TableId
    private Long id;
    /**
     * 设施编号
     */
    private String code;
    /**
     * 设施名称
     */
    private String name;
    /**
     * 设施类型：ACTIVATED_CARBON(活性炭吸附)/CATALYTIC_COMBUSTION(催化燃烧)/BAG_DUST(袋式除尘)/WATER_TREATMENT(废水处理)/OTHER
     */
    private String facilityType;
    /**
     * 关联设备编号（设备档案 id）
     */
    private Long machineryId;
    /**
     * 所在车间编号
     */
    private Long workshopId;
    /**
     * 对应排放口编号
     */
    private String outletCode;
    /**
     * 设计处理能力（描述）
     */
    private String designCapacity;
    /**
     * 活性炭填充量（kg）
     */
    private BigDecimal carbonLoad;
    /**
     * 活性炭更换周期（天）
     */
    private Integer carbonCycleDays;
    /**
     * 最近一次换炭时间
     */
    private LocalDateTime lastCarbonTime;
    /**
     * 废活性炭去向（危废暂存点）
     */
    private String wasteLocation;
    /**
     * 运行状态：RUNNING(运行)/SHUTDOWN(停运)/MAINTENANCE(维护)
     */
    private String status;
    /**
     * 设施照片 URL
     */
    private String photoUrl;
    /**
     * 备注
     */
    private String remark;

}
