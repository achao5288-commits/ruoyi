package cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace;

import cn.iocoder.txgy.framework.common.pojo.CommonResult;
import cn.iocoder.txgy.framework.common.pojo.PageResult;
import cn.iocoder.txgy.framework.common.util.object.BeanUtils;
import cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace.vo.MesSetCarbonReplacePageReqVO;
import cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace.vo.MesSetCarbonReplaceRespVO;
import cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace.vo.MesSetCarbonReplaceSaveReqVO;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.carbonreplace.MesSetCarbonReplaceDO;
import cn.iocoder.txgy.module.mes.service.set.carbonreplace.MesSetCarbonReplaceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import static cn.iocoder.txgy.framework.common.pojo.CommonResult.success;

@Tag(name = "管理后台 - MES 安全环保检测-换炭作业票")
@RestController
@RequestMapping("/mes/safety-env/carbon-replace")
@Validated
public class MesSetCarbonReplaceController {

    @Resource
    private MesSetCarbonReplaceService carbonReplaceService;

    @PostMapping("/create")
    @Operation(summary = "创建换炭作业票")
    @PreAuthorize("@ss.hasPermission('mes:set-carbon-replace:create')")
    public CommonResult<Long> createCarbonReplace(@Valid @RequestBody MesSetCarbonReplaceSaveReqVO createReqVO) {
        return success(carbonReplaceService.createCarbonReplace(createReqVO));
    }

    @PutMapping("/update")
    @Operation(summary = "更新换炭作业票")
    @PreAuthorize("@ss.hasPermission('mes:set-carbon-replace:update')")
    public CommonResult<Boolean> updateCarbonReplace(@Valid @RequestBody MesSetCarbonReplaceSaveReqVO updateReqVO) {
        carbonReplaceService.updateCarbonReplace(updateReqVO);
        return success(true);
    }

    @DeleteMapping("/delete")
    @Operation(summary = "删除换炭作业票")
    @Parameter(name = "id", description = "编号", required = true)
    @PreAuthorize("@ss.hasPermission('mes:set-carbon-replace:delete')")
    public CommonResult<Boolean> deleteCarbonReplace(@RequestParam("id") Long id) {
        carbonReplaceService.deleteCarbonReplace(id);
        return success(true);
    }

    @GetMapping("/get")
    @Operation(summary = "获得换炭作业票")
    @Parameter(name = "id", description = "编号", required = true, example = "1024")
    @PreAuthorize("@ss.hasPermission('mes:set-carbon-replace:query')")
    public CommonResult<MesSetCarbonReplaceRespVO> getCarbonReplace(@RequestParam("id") Long id) {
        MesSetCarbonReplaceDO carbonReplace = carbonReplaceService.getCarbonReplace(id);
        return success(BeanUtils.toBean(carbonReplace, MesSetCarbonReplaceRespVO.class));
    }

    @GetMapping("/page")
    @Operation(summary = "获得换炭作业票分页")
    @PreAuthorize("@ss.hasPermission('mes:set-carbon-replace:query')")
    public CommonResult<PageResult<MesSetCarbonReplaceRespVO>> getCarbonReplacePage(@Valid MesSetCarbonReplacePageReqVO pageReqVO) {
        PageResult<MesSetCarbonReplaceDO> pageResult = carbonReplaceService.getCarbonReplacePage(pageReqVO);
        return success(BeanUtils.toBean(pageResult, MesSetCarbonReplaceRespVO.class));
    }

}
