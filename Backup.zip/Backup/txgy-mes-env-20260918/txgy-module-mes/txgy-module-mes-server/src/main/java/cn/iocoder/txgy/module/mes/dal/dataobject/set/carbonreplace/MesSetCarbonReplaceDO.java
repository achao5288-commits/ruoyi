package cn.iocoder.txgy.module.mes.dal.dataobject.set.carbonreplace;

import cn.iocoder.txgy.framework.mybatis.core.dataobject.BaseDO;
import com.baomidou.mybatisplus.annotation.KeySequence;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * MES 安全环保检测-换炭作业票 DO
 *
 * @author OPENLAB BS
 */
@TableName("mes_set_carbon_replace")
@KeySequence("mes_set_carbon_replace_seq")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MesSetCarbonReplaceDO extends BaseDO {

    /**
     * 编号
     */
    @TableId
    private Long id;
    /**
     * 作业票编号
     */
    private String code;
    /**
     * 治污设施编号（关联 mes_set_facility.id）
     */
    private Long facilityId;
    /**
     * 换炭时间
     */
    private LocalDateTime replaceTime;
    /**
     * 旧炭重量（kg）
     */
    private BigDecimal oldCarbonWeight;
    /**
     * 新炭批次号
     */
    private String newCarbonBatchNo;
    /**
     * 新炭填充量（kg）
     */
    private BigDecimal newCarbonLoad;
    /**
     * 碘值（活性炭吸附性能指标）
     */
    private BigDecimal iodineValue;
    /**
     * 现场照片 URLs（多张逗号分隔）
     */
    private String photoUrls;
    /**
     * 称重数据来源：MANUAL(人工)/SCALE(电子秤自动)
     */
    private String weightSource;
    /**
     * 废活性炭去向（危废暂存点）
     */
    private String wasteLocation;
    /**
     * 状态：DRAFT(草稿)/APPROVED(已审核)/REJECTED(已驳回)
     */
    private String status;
    /**
     * 操作人
     */
    private String operator;
    /**
     * 备注
     */
    private String remark;

}
