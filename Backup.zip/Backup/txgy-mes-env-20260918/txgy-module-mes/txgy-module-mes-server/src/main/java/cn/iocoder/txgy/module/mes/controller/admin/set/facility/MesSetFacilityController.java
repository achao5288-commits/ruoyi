package cn.iocoder.txgy.module.mes.controller.admin.set.facility;

import cn.iocoder.txgy.framework.common.pojo.CommonResult;
import cn.iocoder.txgy.framework.common.pojo.PageResult;
import cn.iocoder.txgy.framework.common.util.object.BeanUtils;
import cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo.MesSetFacilityPageReqVO;
import cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo.MesSetFacilityRespVO;
import cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo.MesSetFacilitySaveReqVO;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.facility.MesSetFacilityDO;
import cn.iocoder.txgy.module.mes.service.set.facility.MesSetFacilityService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import static cn.iocoder.txgy.framework.common.pojo.CommonResult.success;

@Tag(name = "管理后台 - MES 安全环保检测-治污设施台账")
@RestController
@RequestMapping("/mes/safety-env/facility")
@Validated
public class MesSetFacilityController {

    @Resource
    private MesSetFacilityService facilityService;

    @PostMapping("/create")
    @Operation(summary = "创建治污设施台账")
    @PreAuthorize("@ss.hasPermission('mes:set-facility:create')")
    public CommonResult<Long> createFacility(@Valid @RequestBody MesSetFacilitySaveReqVO createReqVO) {
        return success(facilityService.createFacility(createReqVO));
    }

    @PutMapping("/update")
    @Operation(summary = "更新治污设施台账")
    @PreAuthorize("@ss.hasPermission('mes:set-facility:update')")
    public CommonResult<Boolean> updateFacility(@Valid @RequestBody MesSetFacilitySaveReqVO updateReqVO) {
        facilityService.updateFacility(updateReqVO);
        return success(true);
    }

    @DeleteMapping("/delete")
    @Operation(summary = "删除治污设施台账")
    @Parameter(name = "id", description = "编号", required = true)
    @PreAuthorize("@ss.hasPermission('mes:set-facility:delete')")
    public CommonResult<Boolean> deleteFacility(@RequestParam("id") Long id) {
        facilityService.deleteFacility(id);
        return success(true);
    }

    @GetMapping("/get")
    @Operation(summary = "获得治污设施台账")
    @Parameter(name = "id", description = "编号", required = true, example = "1024")
    @PreAuthorize("@ss.hasPermission('mes:set-facility:query')")
    public CommonResult<MesSetFacilityRespVO> getFacility(@RequestParam("id") Long id) {
        MesSetFacilityDO facility = facilityService.getFacility(id);
        return success(BeanUtils.toBean(facility, MesSetFacilityRespVO.class));
    }

    @GetMapping("/page")
    @Operation(summary = "获得治污设施台账分页")
    @PreAuthorize("@ss.hasPermission('mes:set-facility:query')")
    public CommonResult<PageResult<MesSetFacilityRespVO>> getFacilityPage(@Valid MesSetFacilityPageReqVO pageReqVO) {
        PageResult<MesSetFacilityDO> pageResult = facilityService.getFacilityPage(pageReqVO);
        return success(BeanUtils.toBean(pageResult, MesSetFacilityRespVO.class));
    }

}
