package cn.iocoder.txgy.module.mes.dal.mysql.set.tracechain;

import cn.iocoder.txgy.framework.mybatis.core.mapper.BaseMapperX;
import cn.iocoder.txgy.framework.mybatis.core.query.LambdaQueryWrapperX;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.tracechain.MesSetSignRecordDO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * MES 安全环保检测-环环签字记录 Mapper（只增不改不删，无 update/delete 入口）
 *
 * @author OPENLAB BS
 */
@Mapper
public interface MesSetSignRecordMapper extends BaseMapperX<MesSetSignRecordDO> {

    /** 某单据(type+no)的全部签字，按 id 升序 = 时间正序 */
    default List<MesSetSignRecordDO> selectByBiz(String bizType, String bizNo) {
        return selectList(new LambdaQueryWrapperX<MesSetSignRecordDO>()
                .eq(MesSetSignRecordDO::getBizType, bizType)
                .eq(MesSetSignRecordDO::getBizNo, bizNo)
                .orderByAsc(MesSetSignRecordDO::getId));
    }

}
