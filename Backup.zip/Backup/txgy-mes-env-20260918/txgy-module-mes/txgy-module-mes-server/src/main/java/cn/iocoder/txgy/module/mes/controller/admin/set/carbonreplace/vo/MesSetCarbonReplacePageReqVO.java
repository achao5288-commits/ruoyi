package cn.iocoder.txgy.module.mes.controller.admin.set.carbonreplace.vo;

import cn.iocoder.txgy.framework.common.pojo.PageParam;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Schema(description = "管理后台 - MES 安全环保检测-换炭作业票 分页 Request VO")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class MesSetCarbonReplacePageReqVO extends PageParam {

    @Schema(description = "作业票编号", example = "CR-2026-0001")
    private String code;

    @Schema(description = "治污设施编号", example = "1")
    private Long facilityId;

    @Schema(description = "状态", example = "DRAFT")
    private String status;

}
