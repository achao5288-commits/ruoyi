package cn.iocoder.txgy.module.mes.service.set.facility;

import cn.iocoder.txgy.framework.common.pojo.PageResult;
import cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo.MesSetFacilityPageReqVO;
import cn.iocoder.txgy.module.mes.controller.admin.set.facility.vo.MesSetFacilitySaveReqVO;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.facility.MesSetFacilityDO;

import jakarta.validation.Valid;

/**
 * MES 安全环保检测-治污设施台账 Service 接口
 *
 * @author OPENLAB BS
 */
public interface MesSetFacilityService {

    /**
     * 创建治污设施台账
     *
     * @param createReqVO 创建信息
     * @return 编号
     */
    Long createFacility(@Valid MesSetFacilitySaveReqVO createReqVO);

    /**
     * 更新治污设施台账
     *
     * @param updateReqVO 更新信息
     */
    void updateFacility(@Valid MesSetFacilitySaveReqVO updateReqVO);

    /**
     * 删除治污设施台账
     *
     * @param id 编号
     */
    void deleteFacility(Long id);

    /**
     * 校验治污设施台账存在
     *
     * @param id 编号
     */
    void validateFacilityExists(Long id);

    /**
     * 获得治污设施台账
     *
     * @param id 编号
     * @return 治污设施台账
     */
    MesSetFacilityDO getFacility(Long id);

    /**
     * 获得治污设施台账分页
     *
     * @param pageReqVO 分页查询
     * @return 治污设施台账分页
     */
    PageResult<MesSetFacilityDO> getFacilityPage(MesSetFacilityPageReqVO pageReqVO);

}
