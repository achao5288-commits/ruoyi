package cn.iocoder.txgy.module.mes.service.set.tracechain;

import cn.iocoder.txgy.module.mes.dal.dataobject.set.tracechain.MesSetSignRecordDO;
import cn.iocoder.txgy.module.mes.dal.dataobject.set.tracechain.MesSetTraceChainDO;

import java.util.List;

/**
 * MES 安全环保检测-全程追溯链 Service
 *
 * 一期「打基础」核心：现有业务动作（入库/领用/判定复核/台账处置/成品/出库）完成后调用
 * appendNode/recordSign 自动落链落签，"业务动一次，链路长一节"，不额外增加人工录入。
 * 只依赖 Mapper，不依赖其它 Service，避免 bean 环；调用方须在事务内调用，抛错即整体回滚。
 *
 * @author OPENLAB BS
 */
public interface MesSetTraceChainService {

    /**
     * 追加追溯链节点（只增不改）。
     *
     * @param node 节点（traceCode/nodeStage/bizType/bizNo 必填，其余按业务填充）
     */
    void appendNode(MesSetTraceChainDO node);

    /**
     * 记录签字（只增不改不删）。
     *
     * @param sign      签字记录（bizType/bizNo/signRole 必填；signUser/signName 空时自动取当前登录人；signTime 空时取当前时间）
     */
    void recordSign(MesSetSignRecordDO sign);

    /**
     * 追溯查询（一码到底）：
     * 正向(跟去向)——从对象码出发沿"对象→衍生对象"逐层向下（如原料批次→危废桶/成品批次）；
     * 反向(查来源)——从对象码出发沿 parent_codes 逐层向上（如危废桶→原料批次→供应商批次）。
     * 游走深度上限 {@link #MAX_DEPTH}，已访问对象码去重防环。
     *
     * @param code 对象码（批次码/记录号）
     * @return forward=正向节点时间线；backward=反向节点时间线（各自按操作时间升序）
     */
    TraceChainResult getTraceChain(String code);

    /** 某单据的全部签字（按时间正序） */
    List<MesSetSignRecordDO> getSignList(String bizType, String bizNo);

    /** 追溯游走深度上限 */
    int MAX_DEPTH = 10;

    /** 单据类型：污染判定 */
    String BIZ_TYPE_POLLUTION_CHECK = "POLLUTION_CHECK";
    /** 单据类型：污染台账处置流转 */
    String BIZ_TYPE_POLLUTION_LEDGER = "POLLUTION_LEDGER";
    /** 单据类型：采购入库单 */
    String BIZ_TYPE_ITEM_RECEIPT = "WM_ITEM_RECEIPT";
    /** 单据类型：生产领料单 */
    String BIZ_TYPE_PRODUCT_ISSUE = "WM_PRODUCT_ISSUE";
    /** 单据类型：成品入库单 */
    String BIZ_TYPE_PRODUCT_RECEIPT = "WM_PRODUCT_RECEIPT";
    /** 单据类型：销售出库单 */
    String BIZ_TYPE_PRODUCT_SALES = "WM_PRODUCT_SALES";

    /** 追溯查询结果：正向 + 反向两条时间线 */
    class TraceChainResult {

        private List<MesSetTraceChainDO> forward;

        private List<MesSetTraceChainDO> backward;

        public List<MesSetTraceChainDO> getForward() {
            return forward;
        }

        public void setForward(List<MesSetTraceChainDO> forward) {
            this.forward = forward;
        }

        public List<MesSetTraceChainDO> getBackward() {
            return backward;
        }

        public void setBackward(List<MesSetTraceChainDO> backward) {
            this.backward = backward;
        }
    }

}
