"""Copy 18 missing set submodules from old txgycloud to D:/Projects/txgycloud.
Python handles Chinese paths via UTF-8 str API, bypassing PowerShell cmdlet issues.
"""
import shutil
import os
import sys

SRC_ROOT = r'e:\天信管业防腐保温智慧平台\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\java\cn\iocoder\txgy\module\mes'
DST_ROOT = r'D:\Projects\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\java\cn\iocoder\txgy\module\mes'
SRC_RES  = r'e:\天信管业防腐保温智慧平台\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\resources\mapper'
DST_RES  = r'D:\Projects\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\resources\mapper'

MODULES = [
    'carbonemission','chemicalsafety','dustrecord','electricalrecord','emissionoutlet',
    'envreport','exhaustgas','firerecord','gasrecord','hazardouswaste',
    'noiserecord','occupationalhazard','plan','pollutionpermit','ppecheck',
    'pressurevessel','standard','wastewater',
]

LAYERS = ['controller\\admin\\set','service\\set','dal\\mysql\\set','dal\\dataobject\\set']

copied = 0
for m in MODULES:
    for layer in LAYERS:
        src_dir = os.path.join(SRC_ROOT, layer, m)
        dst_dir = os.path.join(DST_ROOT, layer, m)
        if os.path.isdir(src_dir):
            if os.path.isdir(dst_dir):
                shutil.rmtree(dst_dir)
            shutil.copytree(src_dir, dst_dir)
            copied += 1
            print(f'OK  {layer}\\{m}')
        else:
            print(f'SKIP {layer}\\{m}')
    # mapper xml
    src_map = os.path.join(SRC_RES, 'set', m)
    dst_map = os.path.join(DST_RES, 'set', m)
    if os.path.isdir(src_map):
        if os.path.isdir(dst_map):
            shutil.rmtree(dst_map)
        shutil.copytree(src_map, dst_map)
        copied += 1
        print(f'OK  mapper\\set\\{m}')

print(f'\nCopied dir count: {copied}')
print('\n--- controller\\admin\\set subdirs ---')
target = os.path.join(DST_ROOT, 'controller\\admin\\set')
if os.path.isdir(target):
    for d in sorted(os.listdir(target)):
        print(f'  {d}')
