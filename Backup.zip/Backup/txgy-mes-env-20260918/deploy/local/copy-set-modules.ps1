# Copy 18 missing set submodules from old txgycloud to D:/Projects/txgycloud.
# Source path contains Chinese chars; ensure this script file is read as UTF-8 with BOM
# by saving it via the Write tool, and re-encode strings as [System.IO.Path]::GetFullPath to avoid GB2312 mishaps.
$ErrorActionPreference = 'Stop'
$srcRoot = 'e:\天信管业防腐保温智慧平台\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\java\cn\iocoder\txgy\module\mes'
$dstRoot = 'D:\Projects\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\java\cn\iocoder\txgy\module\mes'
$srcRes  = 'e:\天信管业防腐保温智慧平台\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\resources\mapper'
$dstRes  = 'D:\Projects\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\resources\mapper'

$modules = @(
    'carbonemission','chemicalsafety','dustrecord','electricalrecord','emissionoutlet',
    'envreport','exhaustgas','firerecord','gasrecord','hazardouswaste',
    'noiserecord','occupationalhazard','plan','pollutionpermit','ppecheck',
    'pressurevessel','standard','wastewater'
)

$copied = 0
foreach ($m in $modules) {
    foreach ($layer in @('controller\admin\set','service\set','dal\mysql\set','dal\dataobject\set')) {
        $srcDir = Join-Path $srcRoot "$layer\$m"
        $dstDir = Join-Path $dstRoot "$layer\$m"
        if (Test-Path -LiteralPath $srcDir) {
            if (-not (Test-Path -LiteralPath $dstDir)) {
                New-Item -ItemType Directory -Path $dstDir -Force | Out-Null
            }
            Copy-Item -Path "$srcDir\*" -Destination $dstDir -Recurse -Force
            $copied++
        }
    }
    # mapper xml if exists
    $srcMapDir = Join-Path $srcRes "set\$m"
    $dstMapDir = Join-Path $dstRes "set\$m"
    if (Test-Path -LiteralPath $srcMapDir) {
        if (-not (Test-Path -LiteralPath $dstMapDir)) {
            New-Item -ItemType Directory -Path $dstMapDir -Force | Out-Null
        }
        Copy-Item -Path "$srcMapDir\*" -Destination $dstMapDir -Recurse -Force
        $copied++
    }
}
Write-Host ("Copied {0} directories" -f $copied) -ForegroundColor Cyan

# Verify
Write-Host '--- controller/admin/set ---'
Get-ChildItem (Join-Path $dstRoot 'controller\admin\set') -Directory | Select-Object -ExpandProperty Name
