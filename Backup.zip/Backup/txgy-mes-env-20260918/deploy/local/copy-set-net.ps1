# Use .NET API only (PowerShell Test-Path mishandles Chinese paths in some environments).
$srcRoot = 'e:\天信管业防腐保温智慧平台\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\java\cn\iocoder\txgy\module\mes'
$dstRoot = 'D:\Projects\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\java\cn\iocoder\txgy\module\mes'
$srcRes  = 'e:\天信管业防腐保温智慧平台\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\resources\mapper'
$dstRes  = 'D:\Projects\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\resources\mapper'

$modules = @(
    'carbonemission','chemicalsafety','dustrecord','electricalrecord','emissionoutlet',
    'envreport','exhaustgas','firerecord','gasrecord','hazardouswaste',
    'noiserecord','occupationalhazard','plan','pollutionpermit','ppecheck',
    'pressurevessel','standard','wastewater'
)

function Copy-Tree([string]$src, [string]$dst) {
    if (-not [System.IO.Directory]::Exists($src)) { return $false }
    if (-not [System.IO.Directory]::Exists($dst)) { [System.IO.Directory]::CreateDirectory($dst) | Out-Null }
    foreach ($f in [System.IO.Directory]::GetFiles($src, '*', [System.IO.SearchOption]::AllDirectories)) {
        $rel = $f.Substring($src.Length).TrimStart('\','/')
        $dstFile = [System.IO.Path]::Combine($dst, $rel)
        $dstParent = [System.IO.Path]::GetDirectoryName($dstFile)
        if (-not [System.IO.Directory]::Exists($dstParent)) { [System.IO.Directory]::CreateDirectory($dstParent) | Out-Null }
        [System.IO.File]::Copy($f, $dstFile, $true)
    }
    return $true
}

$copied = 0
foreach ($m in $modules) {
    foreach ($layer in @('controller\admin\set','service\set','dal\mysql\set','dal\dataobject\set')) {
        $srcDir = [System.IO.Path]::Combine($srcRoot, $layer, $m)
        $dstDir = [System.IO.Path]::Combine($dstRoot, $layer, $m)
        if (Copy-Tree $srcDir $dstDir) { $copied++ }
    }
    $srcMapDir = [System.IO.Path]::Combine($srcRes, 'set', $m)
    $dstMapDir = [System.IO.Path]::Combine($dstRes, 'set', $m)
    if (Copy-Tree $srcMapDir $dstMapDir) { $copied++ }
}

Write-Host ("Copied dir count: {0}" -f $copied)
Write-Host '---'
Write-Host 'controller\admin\set subdirs:'
[System.IO.Directory]::GetDirectories((Join-Path $dstRoot 'controller\admin\set')) | ForEach-Object { Write-Host ("  " + [System.IO.Path]::GetFileName($_)) }
Write-Host 'service\set subdirs:'
[System.IO.Directory]::GetDirectories((Join-Path $dstRoot 'service\set')) | ForEach-Object { Write-Host ("  " + [System.IO.Path]::GetFileName($_)) }
Write-Host 'dal\mysql\set subdirs:'
[System.IO.Directory]::GetDirectories((Join-Path $dstRoot 'dal\mysql\set')) | ForEach-Object { Write-Host ("  " + [System.IO.Path]::GetFileName($_)) }
Write-Host 'dal\dataobject\set subdirs:'
[System.IO.Directory]::GetDirectories((Join-Path $dstRoot 'dal\dataobject\set')) | ForEach-Object { Write-Host ("  " + [System.IO.Path]::GetFileName($_)) }
