$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$srcRoot = 'e:\天信管业防腐保温智慧平台\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\java\cn\iocoder\txgy\module\mes'
$dstRoot = 'D:\Projects\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\java\cn\iocoder\txgy\module\mes'
$srcRes  = 'e:\天信管业防腐保温智慧平台\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\resources\mapper'
$dstRes  = 'D:\Projects\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\resources\mapper'

$modules = @(
    'carbonemission','chemicalsafety','dustrecord','electricalrecord','emissionoutlet',
    'envreport','exhaustgas','firerecord','gasrecord','hazardouswaste',
    'noiserecord','occupationalhazard','plan','pollutionpermit','ppecheck',
    'pressurevessel','standard','wastewater'
)

foreach ($m in $modules) {
    foreach ($layer in @('controller\admin\set','service\set','dal\mysql\set','dal\dataobject\set')) {
        $srcDir = Join-Path $srcRoot (Join-Path $layer $m)
        $dstDir = Join-Path $dstRoot (Join-Path $layer $m)
        if (Test-Path -LiteralPath $srcDir) {
            if (-not (Test-Path -LiteralPath $dstDir)) {
                New-Item -ItemType Directory -Path $dstDir -Force | Out-Null
            }
            # Use .NET to bypass PowerShell cmdlet encoding pitfalls
            [System.IO.Directory]::CreateDirectory($dstDir) | Out-Null
            foreach ($f in [System.IO.Directory]::GetFiles($srcDir, '*', [System.IO.SearchOption]::AllDirectories)) {
                $rel = $f.Substring($srcDir.Length).TrimStart('\','/')
                $dstFile = [System.IO.Path]::Combine($dstDir, $rel)
                $dstParent = [System.IO.Path]::GetDirectoryName($dstFile)
                if (-not [System.IO.Directory]::Exists($dstParent)) {
                    [System.IO.Directory]::CreateDirectory($dstParent) | Out-Null
                }
                [System.IO.File]::Copy($f, $dstFile, $true)
            }
            Write-Host "OK  $layer\$m"
        } else {
            Write-Host "SKIP $layer\$m (no source)"
        }
    }
    $srcMapDir = Join-Path $srcRes (Join-Path 'set' $m)
    $dstMapDir = Join-Path $dstRes (Join-Path 'set' $m)
    if (Test-Path -LiteralPath $srcMapDir) {
        if (-not [System.IO.Directory]::Exists($dstMapDir)) {
            [System.IO.Directory]::CreateDirectory($dstMapDir) | Out-Null
        }
        foreach ($f in [System.IO.Directory]::GetFiles($srcMapDir, '*', [System.IO.SearchOption]::AllDirectories)) {
            $rel = $f.Substring($srcMapDir.Length).TrimStart('\','/')
            $dstFile = [System.IO.Path]::Combine($dstMapDir, $rel)
            $dstParent = [System.IO.Path]::GetDirectoryName($dstFile)
            if (-not [System.IO.Directory]::Exists($dstParent)) {
                [System.IO.Directory]::CreateDirectory($dstParent) | Out-Null
            }
            [System.IO.File]::Copy($f, $dstFile, $true)
        }
        Write-Host "OK  mapper\set\$m"
    }
}

Write-Host '---'
Write-Host 'controller\admin\set:'
[System.IO.Directory]::GetDirectories((Join-Path $dstRoot 'controller\admin\set')) | ForEach-Object { Write-Host ("  " + [System.IO.Path]::GetFileName($_)) }
