$mysql = 'E:\MySQL9J\bin\mysql.exe'
& $mysql -uroot -proot -D ruoyi-vue-pro -e "DESCRIBE mes_set_carbon_replace;"
Write-Host "---data---"
& $mysql -uroot -proot -D ruoyi-vue-pro -e "SELECT * FROM mes_set_carbon_replace LIMIT 5;"
