"""A方案: 删除 17 个不需要的 set 子模块代码（保留 pollutioncheck/pollutionledger）。

要删除的子模块（17 个）：
- 7 个错分类：carbonemission/chemicalsafety/electricalrecord/firerecord/occupationalhazard/ppecheck/pressurevessel
- 5 个检测记录（合并到 mes_set_inspection_record）：exhaustgas/wastewater/dustrecord/noiserecord/gasrecord
- 5 个小台账（合并到 mes_set_env_basic_ledger）：emissionoutlet/pollutionpermit/standard/plan/envreport
"""
import os
import shutil

SET_ROOT = r'D:\Projects\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\java\cn\iocoder\txgy\module\mes'
MAPPER_RES = r'D:\Projects\txgycloud\txgy-module-mes\txgy-module-mes-server\src\main\resources\mapper\set'

PRUNE_MODULES = [
    # 7 个错分类
    'carbonemission','chemicalsafety','electricalrecord','firerecord',
    'occupationalhazard','ppecheck','pressurevessel',
    # 5 个检测记录（合并）
    'exhaustgas','wastewater','dustrecord','noiserecord','gasrecord',
    # 5 个小台账（合并）
    'emissionoutlet','pollutionpermit','standard','plan','envreport',
]

LAYERS = [
    r'controller\admin\set',
    r'service\set',
    r'dal\mysql\set',
    r'dal\dataobject\set',
]

removed = []
for m in PRUNE_MODULES:
    for layer in LAYERS:
        d = os.path.join(SET_ROOT, layer, m)
        if os.path.isdir(d):
            shutil.rmtree(d)
            removed.append(d)
    # mapper xml
    mp = os.path.join(MAPPER_RES, m)
    if os.path.isdir(mp):
        shutil.rmtree(mp)
        removed.append(mp)

print(f'Removed {len(removed)} directories:')
for d in removed:
    print(f'  {d}')

print('\n--- Remaining controller\\admin\\set subdirs ---')
target = os.path.join(SET_ROOT, r'controller\admin\set')
if os.path.isdir(target):
    for d in sorted(os.listdir(target)):
        print(f'  {d}')

print('\n--- Remaining service\\set subdirs ---')
target = os.path.join(SET_ROOT, r'service\set')
if os.path.isdir(target):
    for d in sorted(os.listdir(target)):
        print(f'  {d}')

print('\n--- Remaining dal\\mysql\\set subdirs ---')
target = os.path.join(SET_ROOT, r'dal\mysql\set')
if os.path.isdir(target):
    for d in sorted(os.listdir(target)):
        print(f'  {d}')

print('\n--- Remaining dal\\dataobject\\set subdirs ---')
target = os.path.join(SET_ROOT, r'dal\dataobject\set')
if os.path.isdir(target):
    for d in sorted(os.listdir(target)):
        print(f'  {d}')

print('\n--- Remaining mapper\\set subdirs ---')
if os.path.isdir(MAPPER_RES):
    for d in sorted(os.listdir(MAPPER_RES)):
        print(f'  {d}')
