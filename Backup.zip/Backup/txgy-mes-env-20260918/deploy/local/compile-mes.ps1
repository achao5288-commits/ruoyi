$env:JAVA_HOME = 'E:\Java\jdk-25'
$env:PATH = "$env:JAVA_HOME\bin;E:\apache-maven-3.9.16\bin;$env:PATH"
Set-Location 'D:\Projects\txgycloud'
$log = 'D:\Projects\txgycloud\deploy\logs\mvn-mes-build.log'
New-Item -ItemType Directory -Force -Path (Split-Path $log) | Out-Null
mvn -B -ntp `
    '-s' 'deploy\local\settings.xml' `
    '-Dmaven.repo.local=E:\maven-repository' `
    '-Dmaven.test.skip=true' `
    '-pl' 'txgy-module-mes/txgy-module-mes-server' `
    '-am' `
    'install' *>&1 |
    Tee-Object -FilePath $log
Write-Host ("Exit = " + $LASTEXITCODE) -ForegroundColor Cyan
Write-Host "Log: $log" -ForegroundColor Cyan
