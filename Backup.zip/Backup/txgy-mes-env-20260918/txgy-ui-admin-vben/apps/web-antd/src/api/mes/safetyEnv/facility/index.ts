import type { PageParam, PageResult } from '@vben/request';

import { requestClient } from '#/api/request';

export namespace MesSetFacilityApi {
  /** MES 安全环保检测-治污设施台账 */
  export interface Facility {
    id?: number; // 编号
    code?: string; // 设施编号
    name?: string; // 设施名称
    facilityType?: string; // 设施类型
    machineryId?: number; // 关联设备编号
    workshopId?: number; // 所在车间编号
    outletCode?: string; // 对应排放口编号
    designCapacity?: string; // 设计处理能力
    carbonLoad?: number; // 活性炭填充量(kg)
    carbonCycleDays?: number; // 活性炭更换周期(天)
    lastCarbonTime?: string; // 最近一次换炭时间
    wasteLocation?: string; // 废活性炭去向
    status?: string; // 运行状态 RUNNING/SHUTDOWN/MAINTENANCE
    photoUrl?: string; // 设施照片 URL
    remark?: string; // 备注
    createTime?: string; // 创建时间
  }
}

/** 查询治污设施台账分页 */
export function getFacilityPage(params: PageParam) {
  return requestClient.get<PageResult<MesSetFacilityApi.Facility>>(
    '/mes/safety-env/facility/page',
    { params },
  );
}

/** 查询治污设施台账详情 */
export function getFacility(id: number) {
  return requestClient.get<MesSetFacilityApi.Facility>(
    `/mes/safety-env/facility/get?id=${id}`,
  );
}

/** 新增治污设施台账 */
export function createFacility(data: MesSetFacilityApi.Facility) {
  return requestClient.post<number>('/mes/safety-env/facility/create', data);
}

/** 修改治污设施台账 */
export function updateFacility(data: MesSetFacilityApi.Facility) {
  return requestClient.put('/mes/safety-env/facility/update', data);
}

/** 删除治污设施台账 */
export function deleteFacility(id: number) {
  return requestClient.delete(`/mes/safety-env/facility/delete?id=${id}`);
}
