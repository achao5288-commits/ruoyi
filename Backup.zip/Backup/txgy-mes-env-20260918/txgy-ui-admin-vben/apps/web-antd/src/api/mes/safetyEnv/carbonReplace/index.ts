import type { PageParam, PageResult } from '@vben/request';

import { requestClient } from '#/api/request';

export namespace MesSetCarbonReplaceApi {
  /** MES 安全环保检测-换炭作业票 */
  export interface CarbonReplace {
    id?: number; // 编号
    code?: string; // 作业票编号
    facilityId?: number; // 治污设施编号
    replaceTime?: string; // 换炭时间
    oldCarbonWeight?: number; // 旧炭重量(kg)
    newCarbonBatchNo?: string; // 新炭批次号
    newCarbonLoad?: number; // 新炭填充量(kg)
    iodineValue?: number; // 碘值
    photoUrls?: string; // 现场照片 URLs
    weightSource?: string; // 称重数据来源 MANUAL/SCALE
    wasteLocation?: string; // 废活性炭去向
    status?: string; // 状态 DRAFT/APPROVED/REJECTED
    operator?: string; // 操作人
    remark?: string; // 备注
    createTime?: string; // 创建时间
  }
}

/** 查询换炭作业票分页 */
export function getCarbonReplacePage(params: PageParam) {
  return requestClient.get<PageResult<MesSetCarbonReplaceApi.CarbonReplace>>(
    '/mes/safety-env/carbon-replace/page',
    { params },
  );
}

/** 查询换炭作业票详情 */
export function getCarbonReplace(id: number) {
  return requestClient.get<MesSetCarbonReplaceApi.CarbonReplace>(
    `/mes/safety-env/carbon-replace/get?id=${id}`,
  );
}

/** 新增换炭作业票 */
export function createCarbonReplace(data: MesSetCarbonReplaceApi.CarbonReplace) {
  return requestClient.post<number>('/mes/safety-env/carbon-replace/create', data);
}

/** 修改换炭作业票 */
export function updateCarbonReplace(data: MesSetCarbonReplaceApi.CarbonReplace) {
  return requestClient.put('/mes/safety-env/carbon-replace/update', data);
}

/** 删除换炭作业票 */
export function deleteCarbonReplace(id: number) {
  return requestClient.delete(`/mes/safety-env/carbon-replace/delete?id=${id}`);
}
