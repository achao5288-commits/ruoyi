<script lang="ts">
import { getLegalBasisList } from '#/api/mes/safetyEnv/pollutionCheck';

export type LegalBasisOption = { label: string; value: string };

/** 法规白名单是静态数据，整个会话只取一次；失败则不缓存，下次打开弹窗重试 */
let optionsPromise: null | Promise<LegalBasisOption[]> = null;

function loadLegalBasisOptions(): Promise<LegalBasisOption[]> {
  optionsPromise ??= getLegalBasisList()
    .then((list) =>
      (list ?? []).map((item) => ({
        label: item.label ?? item.value ?? '',
        value: item.value ?? '',
      })),
    )
    .catch(() => {
      optionsPromise = null;
      return [];
    });
  return optionsPromise;
}
</script>

<script lang="ts" setup>
import { computed, onMounted, ref, useAttrs } from 'vue';

import { Checkbox, CheckboxGroup } from 'ant-design-vue';

defineOptions({ name: 'PollutionLegalBasisCheckbox', inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    disabled?: boolean;
    /** 选中值：法规条款文本，多条以换行连接（判定表的 review_basis 是 VARCHAR） */
    modelValue?: string;
    /**
     * 限定候选：只显示这些法条 value（由操作员勾选的现场特征推出）。
     * 不传或传空数组时显示全量——「只勾其他」时命中为空，必须回落全量，否则无处可选。
     */
    restrictTo?: string[];
  }>(),
  {
    disabled: false,
    modelValue: undefined,
    restrictTo: undefined,
  },
);

const emit = defineEmits<{
  change: [value: string];
  'update:modelValue': [value: string];
}>();

const attrs = useAttrs();
const options = ref<LegalBasisOption[]>([]);

/**
 * 分隔符用换行而非「；」——法条正文本身就含「；」（如第七十八条「…管理计划；建立…管理台账」），
 * 用「；」做分隔会在回填时被切碎。展示处加 whitespace-pre-line 保留换行。
 */
const SEPARATOR = '\n';

const checkedValues = computed<string[]>({
  get: () =>
    props.modelValue
      ? props.modelValue.split(SEPARATOR).filter(Boolean)
      : [],
  set: (val) => {
    const text = (val ?? []).join(SEPARATOR);
    emit('update:modelValue', text);
    emit('change', text);
  },
});

onMounted(async () => {
  options.value = await loadLegalBasisOptions();
});

/**
 * 展示用的选项：有候选限定时只显示候选内的，但**已选值始终保留**——
 * 否则先勾了某条、之后现场特征变化导致它不在候选内时，已选值会从界面上消失。
 */
const displayOptions = computed(() => {
  const restrict = props.restrictTo;
  if (!restrict || restrict.length === 0) {
    return options.value;
  }
  const selected = checkedValues.value;
  return options.value.filter(
    (opt) => restrict.includes(opt.value) || selected.includes(opt.value),
  );
});
</script>

<template>
  <CheckboxGroup
    v-bind="attrs"
    v-model:value="checkedValues"
    :disabled="disabled"
    class="!w-full"
  >
    <div class="grid grid-cols-1 gap-x-4 gap-y-1.5 xl:grid-cols-2">
      <Checkbox v-for="opt in displayOptions" :key="opt.value" :value="opt.value">
        <span class="text-xs leading-5">{{ opt.label }}</span>
      </Checkbox>
    </div>
  </CheckboxGroup>
</template>
