import { getItemPage } from '#/api/mes/md/item';
import { getBatch } from '#/api/mes/wm/batch';
import { getItemReceiptPage } from '#/api/mes/wm/itemreceipt';
import { getItemReceiptLinePage } from '#/api/mes/wm/itemreceipt/line';
import { getProductIssuePage } from '#/api/mes/wm/productissue';
import { getProductIssueLinePage } from '#/api/mes/wm/productissue/line';
import { getProductReceiptPage } from '#/api/mes/wm/productreceipt';
import { getProductReceiptLinePage } from '#/api/mes/wm/productreceipt/line';

/** 关联单据（带 id，供反查批次） */
export interface StageDoc {
  code: string;
  id?: number;
  label: string;
}

/** 判定环节对应的行分页接口；中间废弃物等环节没有来源单据，返回 undefined */
function linePageApiOf(stage?: string) {
  if (stage === 'PURCHASE_INBOUND') {
    return getItemReceiptLinePage;
  }
  if (stage === 'MATERIAL_ISSUE') {
    return getProductIssueLinePage;
  }
  if (stage === 'FINISHED_PRODUCT') {
    return getProductReceiptLinePage;
  }
  return undefined;
}

/** 按物料编码换出物料 id（单据行只存 item_id，过滤只能按 id 走） */
export async function resolveItemIdByCode(itemCode?: string) {
  if (!itemCode) {
    return undefined;
  }
  const page = await getItemPage({
    pageNo: 1,
    pageSize: 20,
    code: itemCode,
  } as any);
  const list = (page?.list as any[]) ?? [];
  const hit = list.find((it) => it.code === itemCode) ?? list[0];
  return hit?.id;
}

/**
 * 拉取该环节下的单据；给了物料编码则只保留行明细里含该物料的单据。
 * 注意：单据与行都只取一页 100 条，超出部分不参与过滤。
 */
export async function fetchDocsOfStage(
  stage?: string,
  itemCode?: string,
): Promise<StageDoc[]> {
  const toDocs = (list: any[]): StageDoc[] =>
    (list ?? [])
      .filter((item) => item.code)
      .map((item) => ({
        code: item.code,
        id: item.id,
        label: item.name ? `${item.code}｜${item.name}` : item.code,
      }));

  let docs: StageDoc[] = [];
  if (stage === 'PURCHASE_INBOUND') {
    const page = await getItemReceiptPage({ pageNo: 1, pageSize: 100 } as any);
    docs = toDocs(page?.list as any[]);
  } else if (stage === 'MATERIAL_ISSUE') {
    const page = await getProductIssuePage({ pageNo: 1, pageSize: 100 } as any);
    docs = toDocs(page?.list as any[]);
  } else if (stage === 'FINISHED_PRODUCT') {
    const page = await getProductReceiptPage({ pageNo: 1, pageSize: 100 } as any);
    docs = toDocs(page?.list as any[]);
  }

  const lineApi = linePageApiOf(stage);
  if (!itemCode || docs.length === 0 || !lineApi) {
    return docs;
  }
  try {
    const itemId = await resolveItemIdByCode(itemCode);
    if (!itemId) {
      return docs;
    }
    const page = await lineApi({ pageNo: 1, pageSize: 100, itemId } as any);
    const parentIds = new Set(
      ((page?.list as any[]) ?? []).map((line) => line.receiptId ?? line.issueId),
    );
    return docs.filter((doc) => doc.id != null && parentIds.has(doc.id));
  } catch {
    // 过滤失败退回全量，不阻断选择
    return docs;
  }
}

/** 从单据行里挑出用于带出批次的那一行：优先命中物料，否则退回第一条带批次的行 */
function pickLine(list: any[] | undefined, itemCode?: string) {
  const rows = (list ?? []).filter((line) => line.batchCode || line.batchId);
  if (rows.length === 0) {
    return undefined;
  }
  if (itemCode) {
    return rows.find((line) => line.itemCode === itemCode) ?? rows[0];
  }
  return rows[0];
}

/** 取单据匹配行的批次号（生产领料行只有 batchId，需再查一次批次） */
export async function resolveBatchCodeOfDoc(
  stage?: string,
  docId?: number,
  itemCode?: string,
): Promise<string | undefined> {
  if (!docId) {
    return undefined;
  }
  if (stage === 'PURCHASE_INBOUND') {
    const page = await getItemReceiptLinePage({
      pageNo: 1,
      pageSize: 50,
      receiptId: docId,
    } as any);
    return pickLine(page?.list, itemCode)?.batchCode;
  }
  if (stage === 'FINISHED_PRODUCT') {
    const page = await getProductReceiptLinePage({
      pageNo: 1,
      pageSize: 50,
      receiptId: docId,
    } as any);
    return pickLine(page?.list, itemCode)?.batchCode;
  }
  if (stage === 'MATERIAL_ISSUE') {
    const page = await getProductIssueLinePage({
      pageNo: 1,
      pageSize: 50,
      issueId: docId,
    } as any);
    const batchId = pickLine(page?.list, itemCode)?.batchId;
    if (batchId) {
      const batch = await getBatch(batchId);
      return batch?.code;
    }
  }
  return undefined;
}

/**
 * 按物料自动匹配关联单号与批次号：取该环节下含该物料的第一张单据，
 * 再从其明细行里取该物料的批次。中间废弃物等无来源单据的环节返回 undefined。
 */
export async function resolveAutoDocAndBatch(
  stage?: string,
  itemCode?: string,
): Promise<undefined | { batchNo?: string; bizNo?: string }> {
  if (!stage || stage === 'WASTE_INTERMEDIATE' || !itemCode) {
    return undefined;
  }
  const doc = (await fetchDocsOfStage(stage, itemCode))[0];
  if (!doc) {
    return undefined;
  }
  return {
    batchNo: await resolveBatchCodeOfDoc(stage, doc.id, itemCode),
    bizNo: doc.code,
  };
}
