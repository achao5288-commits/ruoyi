<script lang="ts" setup>
import type { MesSetPollutionCheckApi } from '#/api/mes/safetyEnv/pollutionCheck';

import { computed, ref } from 'vue';

import { useVbenModal } from '@vben/common-ui';

import { message } from 'ant-design-vue';

import { useVbenForm } from '#/adapter/form';
import { reviewPollutionCheck } from '#/api/mes/safetyEnv/pollutionCheck';
import { $t } from '#/locales';

import { AI_RESULT_MAP, useReviewFormSchema } from '../data';
import {
  parseFieldSigns,
  resolveArticlesBySigns,
  resolveSignLabels,
} from '../field-sign';

const emit = defineEmits(['success']);
/** 待复核记录(含 AI 初筛结果，只读) */
const row = ref<MesSetPollutionCheckApi.PollutionCheck | null>(null);
/** 操作员初判的现场特征文案（由 code 解析而来），只读展示 */
const operatorSignLabels = ref<string[]>([]);
/**
 * 按现场特征收窄后的法条候选 value；为空表示回落全量。
 * 用 ref 存而不是放进 schema，是因为候选要异步解析，schema 必须在拿到结果后重建。
 */
const basisCandidates = ref<string[]>([]);

/** AI 结论对应的强调配色(类名写成完整字面量，否则 Tailwind 扫描不到) */
const AI_TONE: Record<string, { badge: string; card: string; label: string }> =
  {
    CLEAN: {
      badge: 'bg-green-500 text-white',
      card: 'border-green-500/50 bg-green-500/10',
      label: 'text-green-600',
    },
    POLLUTED: {
      badge: 'bg-red-500 text-white',
      card: 'border-red-500/50 bg-red-500/10',
      label: 'text-red-600',
    },
    UNCERTAIN: {
      badge: 'bg-amber-500 text-white',
      card: 'border-amber-500/50 bg-amber-500/10',
      label: 'text-amber-600',
    },
  };

/** 无 AI 结果时回落成中性灰 */
const AI_TONE_FALLBACK = {
  badge: 'bg-gray-400 text-white',
  card: 'border-gray-400/40 bg-gray-400/10',
  label: 'text-gray-500',
};

const aiTone = computed(
  () => AI_TONE[row.value?.aiResult ?? ''] ?? AI_TONE_FALLBACK,
);

/** 置信度：进度条与结论徽标同色，故复用徽标的背景色类 */
const aiPercent = computed(() => row.value?.aiConfidence ?? 0);

const [Form, formApi] = useVbenForm({
  commonConfig: {
    componentProps: {
      class: 'w-full',
    },
    formItemClass: 'col-span-1',
    labelWidth: 120,
  },
  layout: 'horizontal',
  schema: useReviewFormSchema(),
  showDefaultActions: false,
  wrapperClass: 'grid-cols-2',
});

const [Modal, modalApi] = useVbenModal({
  async onConfirm() {
    if (!row.value) {
      return;
    }
    const { valid } = await formApi.validate();
    if (!valid) {
      return;
    }
    const values = (await formApi.getValues()) as MesSetPollutionCheckApi.ReviewPayload;
    // 判「有污染」必须给出法规依据（无污染允许留空）；与后端错误码 1040818008 同一口径
    if (values.reviewResult === 'POLLUTED' && !values.reviewBasis) {
      message.error('判为「有污染」时必须勾选判定依据');
      return;
    }
    modalApi.lock();
    try {
      // 终态收口：无污染/有污染 + 处置与去向(留空由后端按环节×结论取默认)
      await reviewPollutionCheck({
        id: row.value.id!,
        reviewResult: values.reviewResult,
        reviewBasis: values.reviewBasis,
        disposition: values.disposition,
        storageMethod: values.storageMethod,
        location: values.location,
        batchNo: values.batchNo,
        remark: values.remark,
      });
      await modalApi.close();
      emit('success');
      message.success($t('ui.actionMessage.operationSuccess'));
    } finally {
      modalApi.unlock();
    }
  },
  async onOpenChange(isOpen: boolean) {
    if (!isOpen) {
      row.value = null;
      operatorSignLabels.value = [];
      basisCandidates.value = [];
      await formApi.resetForm();
      return;
    }
    const data = modalApi.getData<{ row: MesSetPollutionCheckApi.PollutionCheck }>();
    row.value = data.row;
    // 操作员的现场特征：code 转文案展示，并把命中的法条作为收窄候选
    const signCodes = parseFieldSigns(data.row?.fieldSigns);
    operatorSignLabels.value = await resolveSignLabels(signCodes);
    basisCandidates.value = (await resolveArticlesBySigns(signCodes))
      .map((item) => item.value ?? '')
      .filter(Boolean);
    // 候选必须在表单渲染前注入：schema 重建后 componentProps 才会取到新值
    formApi.setState({
      schema: useReviewFormSchema(() => basisCandidates.value),
    });
    // 回显该记录已有批次号；itemCode 用于把批次下拉过滤到该物料；stage 用于把"去向"切成库位或产线/工位
    formApi.setValues({
      reviewResult: undefined,
      batchNo: data.row?.batchNo ?? undefined,
      itemCode: data.row?.itemCode ?? undefined,
      stage: data.row?.stage ?? undefined,
    });
  },
});
</script>

<template>
  <Modal title="人工复核（终态：无污染 / 有污染）" class="w-2/3">
    <!-- 现场观察：上一环留下的客观事实（不是结论），是本次复核的依据 -->
    <div
      v-if="row && operatorSignLabels.length > 0"
      class="mx-4 mb-3 rounded-lg border border-blue-200 bg-blue-50/60 p-3 dark:border-blue-900 dark:bg-blue-950/30"
    >
      <div class="mb-2 flex items-center justify-between">
        <span class="text-xs font-bold tracking-wide text-blue-600 dark:text-blue-400">
          现场观察
        </span>
        <span class="text-muted-foreground text-xs">
          {{ row.recordNo ?? '' }} · {{ row.itemName ?? '-' }}
        </span>
      </div>
      <div class="flex gap-2 text-xs">
        <span class="text-muted-foreground w-20 shrink-0">发现的现象</span>
        <span class="whitespace-pre-line">
          {{ operatorSignLabels.join('\n') }}
        </span>
      </div>
    </div>

    <!-- AI 判定结果：结论、置信度、依据一眼可见 -->
    <div
      v-if="row"
      class="mx-4 mb-3 rounded-lg border p-3"
      :class="aiTone.card"
    >
      <div class="mb-2 flex items-center justify-between">
        <span class="text-muted-foreground text-xs font-bold tracking-wide">
          AI 初筛判定
        </span>
        <span class="text-muted-foreground text-xs">
          {{ row.recordNo ?? '' }} · {{ row.itemName ?? '-' }}
        </span>
      </div>

      <div class="flex items-center gap-5">
        <span
          class="rounded px-4 py-1 text-lg font-bold tracking-widest"
          :class="aiTone.badge"
        >
          {{ AI_RESULT_MAP[row.aiResult ?? '']?.text ?? row.aiResult ?? '-' }}
        </span>
        <div class="min-w-0 flex-1">
          <div class="mb-1 flex items-baseline gap-2">
            <span class="text-muted-foreground text-xs">置信度</span>
            <span class="text-2xl leading-none font-bold" :class="aiTone.label">
              {{ row.aiConfidence ?? '-' }}<span class="text-sm">%</span>
            </span>
          </div>
          <!-- 自绘进度条：颜色与结论徽标同源，不走 antd 的 strokeColor 色值 -->
          <div
            class="h-1.5 w-full overflow-hidden rounded-full bg-black/10 dark:bg-white/15"
          >
            <div
              class="h-full rounded-full"
              :class="aiTone.badge"
              :style="{ width: `${aiPercent}%` }"
            ></div>
          </div>
        </div>
      </div>

      <div class="mt-3 grid gap-1 text-xs">
        <div class="flex gap-2">
          <span class="text-muted-foreground w-28 shrink-0">判定依据</span>
          <span>{{ row.aiReason ?? '-' }}</span>
        </div>
        <div class="flex gap-2">
          <span class="text-muted-foreground w-28 shrink-0">法规依据</span>
          <span>{{ row.aiBasis ?? '-' }}</span>
        </div>
        <div class="flex gap-2">
          <span class="text-muted-foreground w-28 shrink-0">
            AI 推荐存储方法
          </span>
          <span>{{ row.suggestedStorage ?? '-' }}</span>
        </div>
      </div>
    </div>
    <Form class="mx-4" />
  </Modal>
</template>
