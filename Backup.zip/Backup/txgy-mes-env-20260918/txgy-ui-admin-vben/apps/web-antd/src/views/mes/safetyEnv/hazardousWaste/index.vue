<script lang="ts" setup>
import type { VxeTableGridOptions } from '#/adapter/vxe-table';
import type { MesSetHazardousWasteApi } from '#/api/mes/safetyEnv/hazardousWaste';

import { Page, useVbenModal } from '@vben/common-ui';

import { message, Tag } from 'ant-design-vue';

import { ACTION_ICON, TableAction, useVbenVxeGrid } from '#/adapter/vxe-table';
import {
  deleteHazardousWaste,
  getHazardousWastePage,
} from '#/api/mes/safetyEnv/hazardousWaste';
import { $t } from '#/locales';

import {
  STAGE_TAG_MAP,
  STATUS_TAG_MAP,
  useGridColumns,
  useGridFormSchema,
} from './data';
import Form from './modules/form.vue';

const [FormModal, formModalApi] = useVbenModal({
  connectedComponent: Form,
  destroyOnClose: true,
});

/** 刷新表格 */
function handleRefresh() {
  gridApi.query();
}

/** 新建危废台账 */
function handleCreate() {
  formModalApi.setData({ formType: 'create' }).open();
}

/** 编辑危废台账 */
function handleEdit(row: MesSetHazardousWasteApi.HazardousWaste) {
  formModalApi.setData({ id: row.id, formType: 'update' }).open();
}

/** 删除危废台账 */
async function handleDelete(row: MesSetHazardousWasteApi.HazardousWaste) {
  const label = row.manifestNo ?? '';
  const hideLoading = message.loading({
    content: $t('ui.actionMessage.deleting', [label]),
    duration: 0,
  });
  try {
    await deleteHazardousWaste(row.id!);
    message.success($t('ui.actionMessage.deleteSuccess', [label]));
    handleRefresh();
  } finally {
    hideLoading();
  }
}

const [Grid, gridApi] = useVbenVxeGrid({
  formOptions: {
    schema: useGridFormSchema(),
  },
  gridOptions: {
    columns: useGridColumns(),
    height: 'auto',
    keepSource: true,
    proxyConfig: {
      ajax: {
        query: async ({ page }, formValues) =>
          await getHazardousWastePage({
            pageNo: page.currentPage,
            pageSize: page.pageSize,
            ...formValues,
          }),
      },
    },
    rowConfig: {
      keyField: 'id',
      isHover: true,
    },
    toolbarConfig: {
      refresh: true,
      search: true,
    },
  } as VxeTableGridOptions<MesSetHazardousWasteApi.HazardousWaste>,
});
</script>

<template>
  <Page auto-content-height>
    <FormModal @success="handleRefresh" />
    <Grid table-title="危险废物台账">
      <template #toolbar-tools>
        <TableAction
          :actions="[
            {
              label: '新建危废台账',
              type: 'primary',
              icon: ACTION_ICON.ADD,
              auth: ['mes:set-hazardous-waste:create'],
              onClick: handleCreate,
            },
          ]"
        />
      </template>
      <template #stage="{ row }">
        <Tag v-if="row.stage" :color="STAGE_TAG_MAP[row.stage]?.color">
          {{ STAGE_TAG_MAP[row.stage]?.text ?? row.stage }}
        </Tag>
        <span v-else>-</span>
      </template>
      <template #status="{ row }">
        <Tag v-if="row.status" :color="STATUS_TAG_MAP[row.status]?.color">
          {{ STATUS_TAG_MAP[row.status]?.text ?? row.status }}
        </Tag>
        <span v-else>-</span>
      </template>
      <template #actions="{ row }">
        <TableAction
          :actions="[
            {
              label: $t('common.edit'),
              type: 'link',
              icon: ACTION_ICON.EDIT,
              auth: ['mes:set-hazardous-waste:update'],
              onClick: handleEdit.bind(null, row),
            },
            {
              label: $t('common.delete'),
              type: 'link',
              danger: true,
              icon: ACTION_ICON.DELETE,
              auth: ['mes:set-hazardous-waste:delete'],
              popConfirm: {
                title: $t('ui.actionMessage.deleteConfirm', [row.manifestNo]),
                confirm: handleDelete.bind(null, row),
              },
            },
          ]"
        />
      </template>
    </Grid>
  </Page>
</template>
