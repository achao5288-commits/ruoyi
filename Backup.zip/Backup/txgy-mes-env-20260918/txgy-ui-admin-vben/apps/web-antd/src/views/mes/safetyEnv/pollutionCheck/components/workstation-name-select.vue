<script lang="ts" setup>
import { computed, ref, useAttrs, watchEffect } from 'vue';

import { Select } from 'ant-design-vue';

import { getWorkstationPage } from '#/api/mes/md/workstation';

defineOptions({ name: 'MdWorkstationNameSelect', inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    allowClear?: boolean;
    disabled?: boolean;
    /** 选中值：工位名称文本（判定表的 location 是 VARCHAR，存文本而非 ID） */
    modelValue?: string;
    placeholder?: string;
  }>(),
  {
    allowClear: true,
    disabled: false,
    modelValue: undefined,
    placeholder: '请选择产线/工位',
  },
);

const emit = defineEmits<{
  change: [value: string | undefined];
  'update:modelValue': [value: string | undefined];
}>();

const attrs = useAttrs();
const options = ref<{ label: string; value: string }[]>([]);

const selectValue = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val),
});

function filterOption(input: string, option: any) {
  return String(option?.value ?? '')
    .toLowerCase()
    .includes(input.toLowerCase());
}

/** 一次取全工位（分页接口取前 100 条）；value 用工位名称，便于直接落 VARCHAR 字段 */
watchEffect(async () => {
  const page = await getWorkstationPage({ pageNo: 1, pageSize: 100 });
  options.value = ((page?.list as any[]) ?? [])
    .filter((item) => item.name)
    .map((item) => ({
      label: item.code ? `${item.name}（${item.code}）` : item.name,
      value: item.name,
    }));
});
</script>

<template>
  <Select
    v-bind="attrs"
    v-model:value="selectValue"
    :allow-clear="allowClear"
    class="!w-full"
    :disabled="disabled"
    :filter-option="filterOption"
    :options="options"
    :placeholder="placeholder"
    show-search
    @change="(val) => emit('change', val)"
  />
</template>
