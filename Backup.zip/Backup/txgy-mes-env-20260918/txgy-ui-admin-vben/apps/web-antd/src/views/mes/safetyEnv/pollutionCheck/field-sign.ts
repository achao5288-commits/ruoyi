import type { MesSetPollutionCheckApi } from '#/api/mes/safetyEnv/pollutionCheck';

import { getFieldSignList } from '#/api/mes/safetyEnv/pollutionCheck';

/** 特征清单是静态数据，整个会话只取一次；失败则不缓存，下次调用重试 */
let optionsPromise: null | Promise<MesSetPollutionCheckApi.FieldSignOption[]> =
  null;

export function loadFieldSignOptions(): Promise<
  MesSetPollutionCheckApi.FieldSignOption[]
> {
  optionsPromise ??= getFieldSignList()
    .then((list) => list ?? [])
    .catch(() => {
      optionsPromise = null;
      return [];
    });
  return optionsPromise;
}

/** 把 field_signs 的换行分隔文本切成特征 code 列表 */
export function parseFieldSigns(fieldSigns?: string): string[] {
  return fieldSigns ? fieldSigns.split('\n').filter(Boolean) : [];
}

/**
 * 按选中的特征 code 求命中的法条候选（顺序由后端按法条清单保证稳定）。
 *
 * 打不到任何法条时返回空数组——调用方**必须回落到全量法条**：
 * 操作员只勾「其他（请在说明中描述）」时这里就是空的，
 * 若不复用全量候选，专员判「有污染」时必填依据却无可选项，会卡死。
 */
export async function resolveArticlesBySigns(
  signCodes: string[],
): Promise<MesSetPollutionCheckApi.LegalBasisOption[]> {
  if (signCodes.length === 0) {
    return [];
  }
  const list = await loadFieldSignOptions();
  const picked = list.filter((item) => signCodes.includes(item.value ?? ''));
  const seen = new Set<string>();
  const result: MesSetPollutionCheckApi.LegalBasisOption[] = [];
  for (const item of picked) {
    for (const article of item.articles ?? []) {
      const key = article.value ?? '';
      if (key && !seen.has(key)) {
        seen.add(key);
        result.push(article);
      }
    }
  }
  return result;
}

/** 把特征 code 转成展示文案（供只读回显）；未知 code 原样返回，不吞信息 */
export async function resolveSignLabels(
  signCodes: string[],
): Promise<string[]> {
  if (signCodes.length === 0) {
    return [];
  }
  const list = await loadFieldSignOptions();
  const labelMap = new Map(
    list.map((item) => [item.value ?? '', item.label ?? '']),
  );
  return signCodes.map((code) => labelMap.get(code) || code);
}
