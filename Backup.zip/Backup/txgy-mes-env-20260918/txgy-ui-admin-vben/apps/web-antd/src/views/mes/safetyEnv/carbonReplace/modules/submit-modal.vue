<script lang="ts" setup>
import type { MesSetCarbonReplaceApi } from '#/api/mes/safetyEnv/carbonReplace';

import { computed, ref } from 'vue';

import { useVbenModal } from '@vben/common-ui';
import { formatDateTime } from '@vben/utils';

import { Alert, Descriptions, DescriptionsItem, message, Tag } from 'ant-design-vue';

import { submitCarbonReplace } from '#/api/mes/safetyEnv/carbonReplace';

import { CARBON_REPLACE_STATUS_MAP } from '../data';

const emit = defineEmits(['success']);
/** 待提交的草稿作业票 */
const row = ref<MesSetCarbonReplaceApi.CarbonReplace | null>(null);

/** 旧炭净重为空时后端会拒绝提交，这里先按同一口径拦一道，省一次往返 */
const missingOldWeight = computed(() => row.value?.oldCarbonWeight == null);

const [Modal, modalApi] = useVbenModal({
  async onConfirm() {
    const data = row.value;
    if (!data) {
      return;
    }
    if (missingOldWeight.value) {
      message.warning('提交前必须填写旧活性炭净重（称重后登记入危废台账）');
      return;
    }
    modalApi.lock();
    try {
      await submitCarbonReplace(data.id!);
      await modalApi.close();
      emit('success');
      message.success('已提交，旧活性炭已登记入危废暂存台账');
    } finally {
      modalApi.unlock();
    }
  },
  async onOpenChange(isOpen: boolean) {
    if (!isOpen) {
      row.value = null;
      return;
    }
    const data =
      modalApi.getData<{ row: MesSetCarbonReplaceApi.CarbonReplace }>();
    row.value = data.row;
  },
});
</script>

<template>
  <Modal title="提交换炭作业票" class="w-1/2">
    <div v-if="row" class="mx-4">
      <div class="mb-3 flex items-center gap-2">
        <span class="text-sm text-muted-foreground">作业票号</span>
        <span class="font-medium">{{ row.code ?? '-' }}</span>
        <Tag :color="CARBON_REPLACE_STATUS_MAP[row.status ?? '']?.color">
          {{ CARBON_REPLACE_STATUS_MAP[row.status ?? '']?.text ?? row.status }}
        </Tag>
      </div>
      <Descriptions bordered :column="2" size="small">
        <DescriptionsItem label="治污设施">
          {{ row.facilityName ?? '-' }}
        </DescriptionsItem>
        <DescriptionsItem label="更换时间">
          {{ row.replaceTime ? formatDateTime(row.replaceTime) : '-' }}
        </DescriptionsItem>
        <DescriptionsItem label="旧炭净重">
          {{ row.oldCarbonWeight == null ? '未填写' : `${row.oldCarbonWeight} kg` }}
        </DescriptionsItem>
        <DescriptionsItem label="新炭装填量">
          {{ row.newCarbonLoad == null ? '-' : `${row.newCarbonLoad} kg` }}
        </DescriptionsItem>
        <DescriptionsItem label="产废去向" :span="2">
          {{ row.wasteLocation || '留空，按该设施的默认暂存去向登记' }}
        </DescriptionsItem>
      </Descriptions>
      <Alert
        v-if="missingOldWeight"
        class="mt-3"
        type="warning"
        show-icon
        message="提交前必须填写旧活性炭净重（称重后登记入危废台账）"
        description="请先取消本弹窗，在作业票上补齐「旧活性炭净重」后再提交。"
      />
      <Alert
        v-else
        class="mt-3"
        type="info"
        show-icon
        message="提交后不可再修改"
        description="系统会把本次旧活性炭净重登记入危废暂存台账，并回写该设施的最近换炭时间。"
      />
    </div>
  </Modal>
</template>
