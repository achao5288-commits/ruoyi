import type { VbenFormApi, VbenFormSchema } from '#/adapter/form';
import type { VxeTableGridOptions } from '#/adapter/vxe-table';
import type { MesSetPollutionCheckApi } from '#/api/mes/safetyEnv/pollutionCheck';

import { markRaw } from 'vue';

import { WmBatchCodeSelect } from '#/views/mes/wm/batch/components';

import BizNoSelect from './components/biz-no-select.vue';
import FieldSignCheckbox from './components/field-sign-checkbox.vue';
import LegalBasisCheckbox from './components/legal-basis-checkbox.vue';
import PollutionLocationSelect from './components/location-select.vue';
import StockItemSelect from './components/stock-item-select.vue';
import { resolveAutoDocAndBatch } from './doc-batch';

/** 环节选项 */
export const STAGE_OPTIONS = [
  { label: '采购入库', value: 'PURCHASE_INBOUND' },
  { label: '生产领用', value: 'MATERIAL_ISSUE' },
  { label: '中间废弃物', value: 'WASTE_INTERMEDIATE' },
  { label: '成品', value: 'FINISHED_PRODUCT' },
];

/** 环节文案 */
export const STAGE_MAP: Record<string, string> = Object.fromEntries(
  STAGE_OPTIONS.map((item) => [item.value, item.label]),
);

/** AI 初筛结果 */
export const AI_RESULT_OPTIONS = [
  { label: '无污染', value: 'CLEAN' },
  { label: '有污染', value: 'POLLUTED' },
  { label: '不确定', value: 'UNCERTAIN' },
];

/** AI 结果展示(色值用于 tag) */
export const AI_RESULT_MAP: Record<string, { text: string; color: string }> = {
  CLEAN: { text: '无污染', color: 'success' },
  POLLUTED: { text: '有污染', color: 'error' },
  UNCERTAIN: { text: '不确定', color: 'warning' },
};

/** 人工复核结果(终态二值) */
export const REVIEW_RESULT_OPTIONS = [
  { label: '无污染', value: 'CLEAN' },
  { label: '有污染', value: 'POLLUTED' },
];

/** 人工结果展示 */
export const REVIEW_RESULT_MAP: Record<string, { text: string; color: string }> = {
  CLEAN: { text: '无污染', color: 'success' },
  POLLUTED: { text: '有污染', color: 'error' },
};

/** 处置方式选项 */
export const DISPOSITION_OPTIONS = [
  { label: '正常入库/直接存储', value: 'NORMAL_INBOUND' },
  { label: '受控存储', value: 'CONTROLLED_STORAGE' },
  { label: '允许领用', value: 'ISSUE_ALLOWED' },
  { label: '拒绝领用', value: 'REJECT_ISSUE' },
  { label: '回用', value: 'REUSE' },
  { label: '排放(需合规登记)', value: 'DISCHARGE' },
  { label: '隔离暂存/保存处理', value: 'ISOLATE_STORAGE' },
  { label: '标记存储', value: 'MARKED_STORAGE' },
];

/** 处置方式文案 */
export const DISPOSITION_MAP: Record<string, string> = Object.fromEntries(
  DISPOSITION_OPTIONS.map((item) => [item.value, item.label]),
);

/** 最终存储方法选项（留空则后端沿用 AI 推荐/环节默认） */
export const STORAGE_METHOD_OPTIONS = [
  {
    label: '普通仓储（常温、通风、防潮）',
    value: '普通仓储（常温、通风、防潮常规存放）',
  },
  {
    label: '危化品专库（恒温干燥密封）',
    value: '危化品专库：恒温干燥、密封保存，与禁配物料分间',
  },
  {
    label: '危化品防爆柜（防爆通风）',
    value: '危化品防爆柜：防爆电气、防静电接地、通风降温、小批量快周转',
  },
  {
    label: '污染受控存储（危废暂存间按 HW 分区）',
    value:
      '污染/危废受控存储：密封防渗容器、专用污染管控库位、贴标识并登记暂存台账',
  },
  {
    label: '隔离暂存（挂红牌待处置）',
    value: '隔离区暂存：挂红牌物理隔离，待放行单/处置单',
  },
  {
    label: '一般固废暂存（防扬散防渗漏）',
    value: '一般固废暂存区：防扬散、防流失、防渗漏，单独建账',
  },
];

/** 新增/修改污染判定的表单（AI 初筛字段由后端回填，无需录入） */
export function useFormSchema(formApi?: VbenFormApi): VbenFormSchema[] {
  /** 按物料自动带出关联单号与批次号；已手填/已带出的字段不覆盖 */
  async function autoFillDocAndBatch(itemCode?: string) {
    if (!itemCode || !formApi) {
      return;
    }
    const values =
      (await formApi.getValues()) as MesSetPollutionCheckApi.PollutionCheck;
    if (values.bizNo && values.batchNo) {
      return;
    }
    try {
      const auto = await resolveAutoDocAndBatch(values.stage, itemCode);
      if (!auto) {
        return;
      }
      if (!values.bizNo && auto.bizNo) {
        await formApi.setFieldValue('bizNo', auto.bizNo);
      }
      if (!values.batchNo && auto.batchNo) {
        await formApi.setFieldValue('batchNo', auto.batchNo);
      }
    } catch {
      // 带出失败不影响物料信息回填
    }
  }

  return [
    {
      fieldName: 'id',
      component: 'Input',
      dependencies: {
        triggerFields: [''],
        show: () => false,
      },
    },
    {
      fieldName: 'stage',
      label: '环节',
      component: 'Select',
      componentProps: {
        options: STAGE_OPTIONS,
        placeholder: '请选择判定环节',
        allowClear: true,
      },
      rules: 'required',
    },
    {
      fieldName: 'itemId',
      label: '选择物料/产品',
      component: markRaw(StockItemSelect),
      dependencies: {
        triggerFields: ['stage'],
        componentProps: (values) => ({
          stage: values.stage,
          placeholder: '从该环节对应的仓库中选择',
          // 选中物料后回填名称、编码、规格，后续批次号按该物料过滤。
          // 逐个 setFieldValue 而非 setValues：setValues 内部走 merge，会把用于清空的空值又覆盖回旧值。
          onChange: async (payload: any) => {
            await formApi?.setFieldValue('itemCode', payload?.itemCode ?? '');
            await formApi?.setFieldValue('itemName', payload?.itemName ?? '');
            await formApi?.setFieldValue('itemSpec', payload?.itemSpec ?? '');
            // 顺带按该物料自动带出关联单号与批次号（已手填的字段不覆盖）
            await autoFillDocAndBatch(payload?.itemCode);
          },
        }),
      },
    },
    {
      fieldName: 'itemName',
      label: '物料/产品名称',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '由上方选择带出，无主数据时可手填（如：废活性炭）',
      },
      rules: 'required',
    },
    {
      fieldName: 'itemCode',
      label: '物料/产品编码',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '请输入物料/产品编码',
      },
    },
    {
      fieldName: 'itemSpec',
      label: '规格',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '请输入规格',
      },
    },
    {
      fieldName: 'bizNo',
      label: '关联单号',
      component: markRaw(BizNoSelect),
      componentProps: {
        allowClear: true,
        placeholder: '选择本环节对应的单据号',
        // 选中单据后自动带出该单据的批次号
        onChange: async (payload: any) => {
          await formApi?.setFieldValue('batchNo', payload?.batchCode ?? undefined);
        },
      },
      dependencies: {
        triggerFields: ['stage', 'itemCode'],
        componentProps: (values) => ({
          stage: values.stage,
          // 带上已选物料，供带出批次时优先匹配该物料的明细行
          itemCode: values.itemCode,
          onChange: async (payload: any) => {
            await formApi?.setFieldValue(
              'batchNo',
              payload?.batchCode ?? undefined,
            );
          },
        }),
      },
    },
    {
      fieldName: 'batchNo',
      label: '批次号',
      component: markRaw(WmBatchCodeSelect),
      componentProps: {
        allowClear: true,
        placeholder: '请选择真实批次（有污染判定必须关联）',
      },
      dependencies: {
        triggerFields: ['itemCode'],
        componentProps: (values) => ({
          itemCode: values.itemCode,
        }),
      },
    },
    {
      // 现场这一级只留「观察到的现象」，不下结论——结论由专员复核给出，AI 只作参考。
      // 因此不设必填：没发现异常就留空，强制勾选只会逼出假数据。
      fieldName: 'fieldSigns',
      label: '现场观察',
      component: markRaw(FieldSignCheckbox),
      componentProps: {
        placeholder: '按现场看到的情况勾选（无异常可留空）',
      },
      formItemClass: 'col-span-3',
    },
    {
      fieldName: 'remark',
      label: '备注',
      component: 'Textarea',
      componentProps: {
        placeholder: '请输入备注',
        rows: 2,
      },
      formItemClass: 'col-span-3',
    },
  ];
}

/** 人工复核的表单 */
export function useReviewFormSchema(
  getBasisCandidates?: () => string[],
): VbenFormSchema[] {
  return [
    {
      // 仅用于驱动批次号下拉按该记录物料过滤，不展示
      fieldName: 'itemCode',
      component: 'Input',
      dependencies: {
        triggerFields: [''],
        show: () => false,
      },
    },
    {
      // 仅用于驱动"去向"按环节切换（生产领用→产线/工位，其余→仓库库位），不展示
      fieldName: 'stage',
      component: 'Input',
      dependencies: {
        triggerFields: [''],
        show: () => false,
      },
    },
    {
      fieldName: 'reviewResult',
      label: '人工复核结论',
      component: 'RadioGroup',
      componentProps: {
        options: REVIEW_RESULT_OPTIONS,
      },
      rules: 'required',
    },
    {
      // 判「有污染」时必填，该校验在提交前做（见 modules/review.vue），此处不写 rules
      fieldName: 'reviewBasis',
      label: '判定依据',
      component: markRaw(LegalBasisCheckbox),
      formItemClass: 'col-span-3',
      dependencies: {
        // 按操作员的现场特征收窄候选，省掉翻 8 条法条的负担；
        // 命中为空（只勾「其他」）时传入空数组，组件内部回落全量，否则专员无处可选
        triggerFields: [''],
        componentProps: () => ({
          restrictTo: getBasisCandidates?.() ?? [],
        }),
      },
    },
    {
      fieldName: 'disposition',
      label: '处置方式',
      component: 'Select',
      componentProps: {
        options: DISPOSITION_OPTIONS,
        placeholder: '请选择(留空按环节+结论取默认)',
        allowClear: true,
      },
    },
    {
      fieldName: 'storageMethod',
      label: '最终存储方法',
      component: 'Select',
      componentProps: {
        allowClear: true,
        options: STORAGE_METHOD_OPTIONS,
        placeholder: '留空则沿用 AI 推荐/环节默认',
      },
      dependencies: {
        // 生产领用是把料领去产线投产，不涉及存储，故不展示该字段
        triggerFields: ['stage'],
        show: (values) => values.stage !== 'MATERIAL_ISSUE',
      },
    },
    {
      fieldName: 'location',
      label: '去向',
      component: markRaw(PollutionLocationSelect),
      componentProps: {
        allowClear: true,
      },
      dependencies: {
        // 生产领用是把料领到产线，去向选产线/工位；其余环节去向是仓库库位
        triggerFields: ['stage'],
        componentProps: (values) => ({
          stage: values.stage,
        }),
      },
    },
    {
      fieldName: 'batchNo',
      label: '批次号',
      component: markRaw(WmBatchCodeSelect),
      componentProps: {
        allowClear: true,
        placeholder: '判「有污染」时必填，且须为系统内真实批次',
      },
      dependencies: {
        triggerFields: ['itemCode'],
        componentProps: (values) => ({
          itemCode: values.itemCode,
        }),
      },
    },
    {
      // 依据之外的事实性补充（如现场观察、物料状态），与上方法规条款配套说明判定理由
      fieldName: 'remark',
      label: '复核说明',
      component: 'Textarea',
      componentProps: {
        placeholder:
          '补充说明本次判定的事实依据（如：该批次含切削液残留，暂存于危废暂存间）',
        rows: 2,
      },
      formItemClass: 'col-span-3',
    },
  ];
}

/** 列表的搜索表单 */
export function useGridFormSchema(): VbenFormSchema[] {
  return [
    {
      fieldName: 'stage',
      label: '环节',
      component: 'Select',
      componentProps: {
        allowClear: true,
        options: STAGE_OPTIONS,
        placeholder: '请选择环节',
      },
    },
    {
      fieldName: 'itemName',
      label: '物料名称',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '物料名称模糊',
      },
    },
    {
      fieldName: 'bizNo',
      label: '关联单号',
      component: markRaw(BizNoSelect),
      componentProps: {
        allowClear: true,
        placeholder: '选择本环节对应的单据号',
      },
      dependencies: {
        // 按搜索栏已选的环节列出对应单据；未选环节时退化为手工输入
        triggerFields: ['stage'],
        componentProps: (values) => ({
          stage: values.stage,
        }),
      },
    },
    {
      fieldName: 'batchNo',
      label: '批次号',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '请输入批次号',
      },
    },
    {
      fieldName: 'aiResult',
      label: 'AI 初筛',
      component: 'Select',
      componentProps: {
        allowClear: true,
        options: AI_RESULT_OPTIONS,
        placeholder: '请选择',
      },
    },
    {
      fieldName: 'reviewed',
      label: '判定状态',
      component: 'Select',
      componentProps: {
        allowClear: true,
        options: [
          { label: '待复核', value: false },
          { label: '已复核', value: true },
        ],
        placeholder: '全部',
      },
    },
  ];
}

/** 列表的字段 */
export function useGridColumns(): VxeTableGridOptions<MesSetPollutionCheckApi.PollutionCheck>['columns'] {
  return [
    { field: 'recordNo', title: '记录编号', minWidth: 180, showOverflow: true },
    { field: 'bizNo', title: '关联单号', minWidth: 160, showOverflow: true },
    { field: 'stage', title: '环节', width: 110, slots: { default: 'stage' } },
    { field: 'batchNo', title: '批次号', minWidth: 150, showOverflow: true },
    { field: 'itemName', title: '物料/产品名称', minWidth: 160, showOverflow: true },
    { field: 'aiResult', title: 'AI 初筛', width: 140, slots: { default: 'aiResult' } },
    { field: 'storageMethod', title: '存储方法', minWidth: 180, slots: { default: 'storageMethod' } },
    { field: 'reviewResult', title: '人工复核', width: 110, slots: { default: 'reviewResult' } },
    { field: 'disposition', title: '处置方式', width: 140, formatter: ({ cellValue }) => (cellValue ? (DISPOSITION_MAP[cellValue] ?? cellValue) : '-') },
    { field: 'location', title: '去向/库位', minWidth: 130, showOverflow: true },
    { field: 'reviewBy', title: '复核人', width: 100, showOverflow: true },
    { field: 'reviewTime', title: '复核时间', width: 170, formatter: 'formatDateTime' },
    {
      title: '操作',
      width: 220,
      fixed: 'right',
      slots: {
        default: 'actions',
      },
    },
  ];
}
