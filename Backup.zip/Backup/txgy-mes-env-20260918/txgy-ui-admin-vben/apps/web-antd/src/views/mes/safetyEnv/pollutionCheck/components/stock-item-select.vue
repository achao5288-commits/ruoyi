<script lang="ts" setup>
import { computed, nextTick, ref, useAttrs, watch } from 'vue';

import { IconifyIcon } from '@vben/icons';

import { Input, Tooltip } from 'ant-design-vue';

import StockItemSelectDialog from './stock-item-select-dialog.vue';

defineOptions({ name: 'StockItemSelect', inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    allowClear?: boolean;
    disabled?: boolean;
    /** 选中值：物料编号 */
    modelValue?: number;
    placeholder?: string;
    /** 判定环节：决定弹窗里可选哪些仓库的物料 */
    stage?: string;
  }>(),
  {
    allowClear: true,
    disabled: false,
    modelValue: undefined,
    placeholder: '点击选择该环节对应仓库中的物料',
    stage: undefined,
  },
);

const emit = defineEmits<{
  /**
   * 携带该物料的编码/名称/规格，供外层回填。
   * 清空时显式传 null —— 外层 setValues 走 lodash.mergeWith，undefined 会被跳过而清不掉字段。
   */
  change: [
    payload: {
      itemCode?: null | string;
      itemName?: null | string;
      itemSpec?: null | string;
    },
  ];
  'update:modelValue': [value: number | undefined];
}>();

const attrs = useAttrs();
const dialogRef = ref<InstanceType<typeof StockItemSelectDialog>>();
const hovering = ref(false);
const selected = ref<any>();

const disabled = computed(() => props.disabled || !props.stage);
const displayLabel = computed(() => selected.value?.itemName ?? '');
const showClear = computed(
  () =>
    props.allowClear &&
    !disabled.value &&
    hovering.value &&
    props.modelValue != null,
);

/** 清空已选物料 */
function clearSelected() {
  selected.value = undefined;
  emit('update:modelValue', undefined);
  emit('change', { itemCode: null, itemName: null, itemSpec: null });
}

/** 打开选择弹窗；点清除图标时只清空、不打开 */
function handleClick(event: MouseEvent) {
  if (disabled.value) {
    return;
  }
  const target = event.target as HTMLElement;
  if (showClear.value && target.closest('.ant-input-suffix')) {
    event.stopPropagation();
    clearSelected();
    return;
  }
  dialogRef.value?.open(props.stage);
}

/** 回填选中的物料 */
function handleSelected(row: any) {
  selected.value = row;
  emit('update:modelValue', row.itemId);
  emit('change', {
    itemCode: row.itemCode,
    itemName: row.itemName,
    itemSpec: row.specification,
  });
}

// 换环节后原物料可能已不在该环节的仓库范围内，清空避免留下无效值。
// 必须等一个 tick：环节自身的写入与这里同处一个更新周期，立即清会被随后的写入覆盖回去。
watch(
  () => props.stage,
  async () => {
    if (!selected.value) {
      return;
    }
    await nextTick();
    clearSelected();
  },
  { flush: 'post' },
);
</script>

<template>
  <div
    v-bind="attrs"
    class="w-full"
    :class="disabled ? 'cursor-not-allowed' : 'cursor-pointer'"
    @click="handleClick"
    @mouseenter="hovering = true"
    @mouseleave="hovering = false"
  >
    <Tooltip :mouse-enter-delay="0.5" :open="selected ? undefined : false">
      <template #title>
        <div v-if="selected" class="leading-6">
          <div>编码：{{ selected.itemCode || '-' }}</div>
          <div>名称：{{ selected.itemName || '-' }}</div>
          <div>规格：{{ selected.specification || '-' }}</div>
          <div>所在仓库：{{ selected.warehouseName || '-' }}</div>
        </div>
      </template>
      <Input
        :disabled="disabled"
        :placeholder="stage ? placeholder : '请先选择环节'"
        :value="displayLabel"
        readonly
      >
        <template #suffix>
          <IconifyIcon
            class="size-4"
            :icon="showClear ? 'lucide:circle-x' : 'lucide:search'"
          />
        </template>
      </Input>
    </Tooltip>
  </div>
  <StockItemSelectDialog ref="dialogRef" @selected="handleSelected" />
</template>
