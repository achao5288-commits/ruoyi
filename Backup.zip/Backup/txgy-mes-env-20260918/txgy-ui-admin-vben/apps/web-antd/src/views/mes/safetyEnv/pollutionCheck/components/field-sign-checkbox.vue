<script lang="ts" setup>
import type { MesSetPollutionCheckApi } from '#/api/mes/safetyEnv/pollutionCheck';

import { computed, onMounted, ref, useAttrs } from 'vue';

import { Checkbox, CheckboxGroup } from 'ant-design-vue';

import { loadFieldSignOptions } from '../field-sign';

defineOptions({ name: 'PollutionFieldSignCheckbox', inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    disabled?: boolean;
    /** 选中值：特征 code，多条以换行连接（判定表的 field_signs 是 VARCHAR） */
    modelValue?: string;
  }>(),
  {
    disabled: false,
    modelValue: undefined,
  },
);

const emit = defineEmits<{
  change: [value: string];
  'update:modelValue': [value: string];
}>();

const attrs = useAttrs();
const options = ref<MesSetPollutionCheckApi.FieldSignOption[]>([]);

/** 分隔符用换行，与复核依据 reviewBasis 同口径 */
const SEPARATOR = '\n';

const checkedValues = computed<string[]>({
  get: () =>
    props.modelValue ? props.modelValue.split(SEPARATOR).filter(Boolean) : [],
  set: (val) => {
    const text = (val ?? []).join(SEPARATOR);
    emit('update:modelValue', text);
    emit('change', text);
  },
});

onMounted(async () => {
  options.value = await loadFieldSignOptions();
});
</script>

<template>
  <CheckboxGroup
    v-bind="attrs"
    v-model:value="checkedValues"
    :disabled="disabled"
    class="!w-full"
  >
    <div class="grid grid-cols-1 gap-x-4 gap-y-1.5 xl:grid-cols-2">
      <Checkbox v-for="opt in options" :key="opt.value" :value="opt.value">
        <span class="text-xs leading-5">{{ opt.label }}</span>
      </Checkbox>
    </div>
  </CheckboxGroup>
</template>
