<script lang="ts" setup>
import { computed, useAttrs } from 'vue';

import { WmLocationPathSelect } from '#/views/mes/wm/warehouse/components';

import WorkstationNameSelect from './workstation-name-select.vue';

defineOptions({ name: 'PollutionLocationSelect', inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    allowClear?: boolean;
    disabled?: boolean;
    /** 选中值：文本（判定表的 location 是 VARCHAR，存文本而非 ID） */
    modelValue?: string;
    placeholder?: string;
    /** 判定环节：生产领用是把料领到产线，去向选工位；其余环节去向是仓库库位 */
    stage?: string;
  }>(),
  {
    allowClear: true,
    disabled: false,
    modelValue: undefined,
    placeholder: undefined,
    stage: undefined,
  },
);

const emit = defineEmits<{
  change: [value: string | undefined];
  'update:modelValue': [value: string | undefined];
}>();

const attrs = useAttrs();

const isIssueStage = computed(() => props.stage === 'MATERIAL_ISSUE');

const selectValue = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val),
});
</script>

<template>
  <WorkstationNameSelect
    v-if="isIssueStage"
    v-bind="attrs"
    v-model="selectValue"
    :allow-clear="allowClear"
    :disabled="disabled"
    :placeholder="placeholder ?? '请选择产线/工位'"
    @change="(val) => emit('change', val)"
  />
  <WmLocationPathSelect
    v-else
    v-bind="attrs"
    v-model="selectValue"
    :allow-clear="allowClear"
    :disabled="disabled"
    :placeholder="placeholder ?? '请选择去向/库位'"
    @change="(val) => emit('change', val)"
  />
</template>
