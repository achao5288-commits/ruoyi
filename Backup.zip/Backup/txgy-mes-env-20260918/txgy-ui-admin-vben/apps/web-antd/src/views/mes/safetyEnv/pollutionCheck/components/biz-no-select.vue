<script lang="ts" setup>
import { computed, ref, useAttrs, watch } from 'vue';

import { Input, Select } from 'ant-design-vue';

import { fetchDocsOfStage, resolveBatchCodeOfDoc } from '../doc-batch';

defineOptions({ name: 'BizNoSelect', inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    allowClear?: boolean;
    disabled?: boolean;
    /** 物料/产品编码：用于从单据多行明细中挑出该物料对应的行 */
    itemCode?: string;
    /** 选中值：关联单号文本 */
    modelValue?: string;
    placeholder?: string;
    /** 判定环节：决定可选的单据来源 */
    stage?: string;
  }>(),
  {
    allowClear: true,
    disabled: false,
    itemCode: undefined,
    modelValue: undefined,
    placeholder: '请选择关联单号',
    stage: undefined,
  },
);

const emit = defineEmits<{
  /** 携带该单据解析出的批次号，供外层自动带出批次 */
  change: [payload: { batchCode?: string; code?: string }];
  'update:modelValue': [value: string | undefined];
}>();

const attrs = useAttrs();
const docs = ref<{ code: string; id?: number; label: string }[]>([]);

/** 中间废弃物（及未选环节）在系统里没有来源单据，退化为手工输入 */
const freeText = computed(
  () => !props.stage || props.stage === 'WASTE_INTERMEDIATE',
);

const freeTextPlaceholder = computed(() =>
  props.stage
    ? '本环节无来源单据，请手工输入'
    : '请先选择环节，或直接输入单号',
);

const options = computed(() =>
  docs.value.map((item) => ({ label: item.label, value: item.code })),
);

const selectValue = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val),
});

/** 拉取该环节下（并按物料过滤）的可选单据 */
async function loadOptions() {
  docs.value = [];
  try {
    docs.value = await fetchDocsOfStage(props.stage, props.itemCode);
  } catch {
    // 拉取失败保持空列表，不阻断选择
  }
}

/** 选中单据后回传该单据的批次号，由表单自动带出批次 */
async function handleChange(val: any) {
  let batchCode: string | undefined;
  const doc = docs.value.find((item) => item.code === val);
  if (doc?.id) {
    try {
      batchCode = await resolveBatchCodeOfDoc(
        props.stage,
        doc.id,
        props.itemCode,
      );
    } catch {
      batchCode = undefined;
    }
  }
  emit('change', { batchCode, code: val });
}

watch(() => [props.stage, props.itemCode], loadOptions, { immediate: true });
</script>

<template>
  <Input
    v-if="freeText"
    v-bind="attrs"
    v-model:value="selectValue"
    :allow-clear="allowClear"
    :disabled="disabled"
    :placeholder="freeTextPlaceholder"
  />
  <Select
    v-else
    v-bind="attrs"
    v-model:value="selectValue"
    :allow-clear="allowClear"
    class="!w-full"
    :disabled="disabled"
    :options="options"
    :placeholder="placeholder"
    show-search
    @change="handleChange"
  />
</template>
