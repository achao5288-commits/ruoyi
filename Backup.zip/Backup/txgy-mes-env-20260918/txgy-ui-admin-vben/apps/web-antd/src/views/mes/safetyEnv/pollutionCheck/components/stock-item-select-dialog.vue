<script lang="ts" setup>
import type { VxeTableGridOptions } from '#/adapter/vxe-table';

import { nextTick, ref } from 'vue';

import { Input, message, Modal } from 'ant-design-vue';

import { useVbenVxeGrid } from '#/adapter/vxe-table';
import { getMaterialStockPage } from '#/api/mes/wm/materialstock';
import { getWarehouseSimpleList } from '#/api/mes/wm/warehouse';

defineOptions({ name: 'StockItemSelectDialog' });

const emit = defineEmits<{
  selected: [row: any];
}>();

/**
 * 环节 → 仓库编码：按「能不能入这个仓 / 能不能从这个仓领」划分。
 * 用仓库编码而非 id，因为各租户仓库 id 不同，编码跨租户一致。
 */
const STAGE_WAREHOUSE_CODES: Record<string, string[]> = {
  PURCHASE_INBOUND: ['WH-RAW', 'WH-CHEM'],
  MATERIAL_ISSUE: ['WH-RAW', 'WH-CHEM', 'WH-ISOLATE'],
  FINISHED_PRODUCT: ['WH-FIN'],
  WASTE_INTERMEDIATE: ['WH-HAZWASTE', 'WH-GENSW'],
};

const open = ref(false);
const keyword = ref('');
const stage = ref<string>();
/** 该环节范围内去重后的库存物料行 */
const allRows = ref<any[]>([]);
/** 当前选中行 */
const picked = ref<any>();

const [Grid, gridApi] = useVbenVxeGrid({
  gridOptions: {
    columns: [
      { field: 'itemCode', title: '物料编码', width: 180 },
      { field: 'itemName', title: '物料名称', minWidth: 240 },
      {
        field: 'specification',
        title: '规格',
        minWidth: 220,
        showOverflow: true,
      },
      { field: 'unitMeasureName', title: '单位', width: 80 },
      { field: 'warehouseName', title: '所在仓库', width: 150 },
      { field: 'quantity', title: '库存数量', width: 110 },
    ],
    data: [],
    height: 520,
    rowConfig: { isHover: true, keyField: 'itemCode' },
    radioConfig: { highlight: true, trigger: 'row' },
    toolbarConfig: { refresh: false, search: false },
  } as VxeTableGridOptions<any>,
  gridEvents: {
    // 双击直接确认，沿用项目里物料选择弹窗的习惯
    cellDblclick: ({ row }: any) => {
      picked.value = row;
      handleConfirm();
    },
    radioChange: ({ row }: any) => {
      picked.value = row;
    },
  },
});

/** 按环节取范围内仓库的库存，按物料去重（同物料可能多批次/多库位） */
async function loadScopedRows() {
  allRows.value = [];
  const codes = stage.value ? STAGE_WAREHOUSE_CODES[stage.value] : undefined;
  if (!codes) {
    return;
  }
  const warehouses = await getWarehouseSimpleList();
  const ids = (warehouses ?? [])
    .filter((w: any) => codes.includes(w.code))
    .map((w: any) => w.id);
  const merged: any[] = [];
  for (const warehouseId of ids) {
    const page = await getMaterialStockPage({
      pageNo: 1,
      pageSize: 100,
      warehouseId,
    } as any);
    merged.push(...((page?.list as any[]) ?? []));
  }
  const seen = new Set<number>();
  allRows.value = merged.filter((row) => {
    if (row.itemId == null || seen.has(row.itemId)) {
      return false;
    }
    seen.add(row.itemId);
    return true;
  });
}

/** 关键字过滤：编码 / 名称 / 规格 / 所在仓库 */
async function applyFilter() {
  const kw = keyword.value.trim().toLowerCase();
  const rows = kw
    ? allRows.value.filter((row) =>
        [
          row.itemCode,
          row.itemName,
          row.specification,
          row.warehouseName,
        ].some((value) => (value ?? '').toLowerCase().includes(kw)),
      )
    : allRows.value;
  await gridApi.grid.reloadData(rows);
  picked.value = undefined;
  await gridApi.grid.clearRadioRow();
}

/** 打开弹窗（需带上当前环节，决定可选范围） */
async function openModal(currentStage?: string) {
  stage.value = currentStage;
  keyword.value = '';
  picked.value = undefined;
  open.value = true;
  await loadScopedRows();
  await nextTick();
  await gridApi.grid.reloadData(allRows.value);
}

function handleConfirm() {
  if (!picked.value) {
    message.warning('请选择一条数据');
    return;
  }
  emit('selected', picked.value);
  open.value = false;
}

defineExpose({ open: openModal });
</script>

<template>
  <Modal
    v-model:open="open"
    title="选择物料/产品"
    width="80%"
    :destroy-on-close="true"
    @ok="handleConfirm"
  >
    <div class="mb-3 flex items-center gap-3">
      <Input
        v-model:value="keyword"
        allow-clear
        class="!w-96"
        placeholder="输入物料编码 / 名称 / 规格 / 仓库搜索"
        @change="applyFilter"
      />
      <span class="text-sm opacity-60">
        仅列出该环节对应仓库中的物料（双击可直接选中）
      </span>
    </div>
    <Grid table-title="可选物料" />
  </Modal>
</template>
