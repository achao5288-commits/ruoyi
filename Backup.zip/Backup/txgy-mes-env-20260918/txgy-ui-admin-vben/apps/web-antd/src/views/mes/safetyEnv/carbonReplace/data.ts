import type { VbenFormSchema } from '#/adapter/form';
import type { VxeTableGridOptions } from '#/adapter/vxe-table';
import type { MesSetCarbonReplaceApi } from '#/api/mes/safetyEnv/carbonReplace';

/** 称重数据来源选项 */
export const WEIGHT_SOURCE_OPTIONS = [
  { label: '人工录入', value: 'MANUAL' },
  { label: '电子秤自动', value: 'SCALE' },
];

/** 状态选项 */
export const STATUS_OPTIONS = [
  { label: '草稿', value: 'DRAFT' },
  { label: '已审核', value: 'APPROVED' },
  { label: '已驳回', value: 'REJECTED' },
];

/** 状态展示(色值用于 tag) */
export const STATUS_TAG_MAP: Record<string, { text: string; color: string }> = {
  DRAFT: { text: '草稿', color: 'default' },
  APPROVED: { text: '已审核', color: 'success' },
  REJECTED: { text: '已驳回', color: 'error' },
};

/** 新增/修改换炭作业票的表单 */
export function useFormSchema(): VbenFormSchema[] {
  return [
    {
      fieldName: 'id',
      component: 'Input',
      dependencies: {
        triggerFields: [''],
        show: () => false,
      },
    },
    {
      fieldName: 'code',
      label: '作业票编号',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '如：CR-2026-0001',
      },
      rules: 'required',
    },
    {
      fieldName: 'facilityId',
      label: '治污设施编号',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        placeholder: '关联治污设施 id',
      },
      rules: 'required',
    },
    {
      fieldName: 'replaceTime',
      label: '换炭时间',
      component: 'DatePicker',
      componentProps: {
        showTime: true,
        valueFormat: 'YYYY-MM-DD HH:mm:ss',
        placeholder: '请选择换炭时间',
      },
    },
    {
      fieldName: 'oldCarbonWeight',
      label: '旧炭重量(kg)',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        step: 0.001,
        precision: 3,
        placeholder: '旧炭实际重量',
      },
    },
    {
      fieldName: 'newCarbonBatchNo',
      label: '新炭批次号',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '新活性炭批次号',
      },
    },
    {
      fieldName: 'newCarbonLoad',
      label: '新炭填充量(kg)',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        step: 0.001,
        precision: 3,
        placeholder: '新炭填充量',
      },
    },
    {
      fieldName: 'iodineValue',
      label: '碘值',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        step: 1,
        precision: 2,
        placeholder: '活性炭碘值',
      },
    },
    {
      fieldName: 'weightSource',
      label: '称重来源',
      component: 'Select',
      componentProps: {
        options: WEIGHT_SOURCE_OPTIONS,
        allowClear: true,
        placeholder: '请选择称重来源',
      },
    },
    {
      fieldName: 'wasteLocation',
      label: '废活性炭去向',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '如：危废暂存间 A-01',
      },
    },
    {
      fieldName: 'operator',
      label: '操作人',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '请输入操作人',
      },
    },
    {
      fieldName: 'status',
      label: '状态',
      component: 'Select',
      componentProps: {
        options: STATUS_OPTIONS,
        allowClear: true,
        placeholder: '请选择状态',
      },
    },
    {
      fieldName: 'photoUrls',
      label: '现场照片 URLs',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '多张照片逗号分隔',
      },
    },
    {
      fieldName: 'remark',
      label: '备注',
      component: 'Textarea',
      componentProps: {
        placeholder: '请输入备注',
        rows: 2,
      },
      formItemClass: 'col-span-3',
    },
  ];
}

/** 列表的搜索表单 */
export function useGridFormSchema(): VbenFormSchema[] {
  return [
    {
      fieldName: 'code',
      label: '作业票编号',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '作业票编号',
      },
    },
    {
      fieldName: 'facilityId',
      label: '治污设施',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        placeholder: '设施 id',
      },
    },
    {
      fieldName: 'status',
      label: '状态',
      component: 'Select',
      componentProps: {
        allowClear: true,
        options: STATUS_OPTIONS,
        placeholder: '请选择状态',
      },
    },
  ];
}

/** 列表的字段 */
export function useGridColumns(): VxeTableGridOptions<MesSetCarbonReplaceApi.CarbonReplace>['columns'] {
  return [
    { field: 'code', title: '作业票编号', minWidth: 160 },
    { field: 'facilityId', title: '治污设施', width: 100 },
    { field: 'replaceTime', title: '换炭时间', width: 170, formatter: 'formatDateTime' },
    { field: 'oldCarbonWeight', title: '旧炭重量', width: 110, formatter: ({ cellValue }) => (cellValue != null ? `${cellValue} kg` : '-') },
    { field: 'newCarbonBatchNo', title: '新炭批次号', minWidth: 140 },
    { field: 'newCarbonLoad', title: '新炭填充量', width: 110, formatter: ({ cellValue }) => (cellValue != null ? `${cellValue} kg` : '-') },
    { field: 'iodineValue', title: '碘值', width: 90 },
    { field: 'weightSource', title: '称重来源', width: 100, formatter: ({ cellValue }) => (cellValue ? (WEIGHT_SOURCE_OPTIONS.find((o) => o.value === cellValue)?.label ?? cellValue) : '-') },
    { field: 'wasteLocation', title: '废活性炭去向', minWidth: 140, showOverflow: true },
    { field: 'operator', title: '操作人', width: 100 },
    { field: 'status', title: '状态', width: 100, slots: { default: 'status' } },
    { field: 'remark', title: '备注', minWidth: 150, showOverflow: true },
    { field: 'createTime', title: '创建时间', width: 170, formatter: 'formatDateTime' },
    {
      title: '操作',
      width: 160,
      fixed: 'right',
      slots: {
        default: 'actions',
      },
    },
  ];
}
