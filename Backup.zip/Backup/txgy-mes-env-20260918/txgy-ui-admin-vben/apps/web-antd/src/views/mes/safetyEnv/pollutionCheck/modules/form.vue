<script lang="ts" setup>
import type { MesSetPollutionCheckApi } from '#/api/mes/safetyEnv/pollutionCheck';

import { computed, ref } from 'vue';

import { useVbenModal } from '@vben/common-ui';
import { IconifyIcon } from '@vben/icons';

import { Button, message } from 'ant-design-vue';

import { useVbenForm } from '#/adapter/form';
import {
  createPollutionCheck,
  getPollutionCheck,
  prescreenPollutionCheck,
  updatePollutionCheck,
} from '#/api/mes/safetyEnv/pollutionCheck';
import { $t } from '#/locales';

import { AI_RESULT_MAP, useFormSchema } from '../data';
import { resolveAutoDocAndBatch } from '../doc-batch';

const emit = defineEmits(['success']);
const formType = ref<'create' | 'update'>('create');
const getTitle = computed(() =>
  formType.value === 'update'
    ? $t('ui.actionTitle.edit', ['污染判定'])
    : $t('ui.actionTitle.create', ['污染判定']),
);
/** AI 初筛预览(不落库) */
const aiSuggestion = ref<MesSetPollutionCheckApi.AiSuggestion | null>(null);
const previewing = ref(false);

/** 未出结果/结果未知时用的默认配色 */
const DEFAULT_AI_THEME = {
  bar: 'bg-amber-500',
  bg: 'bg-amber-50',
  border: 'border-amber-200',
  text: 'text-amber-600',
};

/** AI 结果对应的横幅配色 */
const AI_THEME: Record<string, typeof DEFAULT_AI_THEME> = {
  CLEAN: {
    bar: 'bg-green-500',
    bg: 'bg-green-50',
    border: 'border-green-200',
    text: 'text-green-600',
  },
  POLLUTED: {
    bar: 'bg-red-500',
    bg: 'bg-red-50',
    border: 'border-red-200',
    text: 'text-red-600',
  },
  UNCERTAIN: DEFAULT_AI_THEME,
};

/** 当前初筛结果的横幅配色(未出结果时按"不确定"着色) */
const aiTheme = computed(
  () => AI_THEME[aiSuggestion.value?.aiResult ?? ''] ?? DEFAULT_AI_THEME,
);

/** 当前初筛结果的结论文案 */
const aiResultText = computed(
  () => AI_RESULT_MAP[aiSuggestion.value?.aiResult ?? '']?.text ?? '未知',
);

/** 按初筛结论给出对应的复核动作建议 */
const aiAdvice = computed(() => {
  switch (aiSuggestion.value?.aiResult) {
    case 'CLEAN': {
      return '可按常规流程入库 / 投产，复核时确认「无污染」即可。';
    }
    case 'POLLUTED': {
      return '建议复核判「有污染」并登记污染暂存台账，去向按其形态选择对应库位。';
    }
    default: {
      return '信息不足，建议补充规格 / 成分后重新初筛，复核时由人工确认。';
    }
  }
});

const [Form, formApi] = useVbenForm({
  commonConfig: {
    componentProps: {
      class: 'w-full',
    },
    formItemClass: 'col-span-1',
    labelWidth: 120,
  },
  layout: 'horizontal',
  schema: useFormSchema(),
  showDefaultActions: false,
  wrapperClass: 'grid-cols-3',
});

/**
 * 自动带出关联单号与批次号：取该环节下含当前物料的第一张单据。
 * 只在字段为空时填，不覆盖用户已经选好的值。
 */
async function autoFillDocAndBatch(
  values: MesSetPollutionCheckApi.PollutionCheck,
) {
  try {
    const auto = await resolveAutoDocAndBatch(values.stage, values.itemCode);
    if (!auto) {
      return;
    }
    if (!values.bizNo && auto.bizNo) {
      await formApi.setFieldValue('bizNo', auto.bizNo);
    }
    if (!values.batchNo && auto.batchNo) {
      await formApi.setFieldValue('batchNo', auto.batchNo);
    }
  } catch {
    // 自动带出失败不影响初筛结论展示
  }
}

/** AI 初筛预览：按当前填写的物料信息调用后端(不落库)，并自动带出单据与批次 */
async function handlePrescreen() {
  const values = (await formApi.getValues()) as MesSetPollutionCheckApi.PollutionCheck;
  if (!values.itemName) {
    message.warning('请先选择或填写物料/产品名称');
    return;
  }
  previewing.value = true;
  try {
    aiSuggestion.value = await prescreenPollutionCheck(values);
    await autoFillDocAndBatch(values);
  } finally {
    previewing.value = false;
  }
}

const [Modal, modalApi] = useVbenModal({
  async onConfirm() {
    const { valid } = await formApi.validate();
    if (!valid) {
      return;
    }
    modalApi.lock();
    // 提交表单；后端自动执行 AI 初筛并落为待复核
    const data = (await formApi.getValues()) as MesSetPollutionCheckApi.PollutionCheck;
    try {
      await (formType.value === 'update'
        ? updatePollutionCheck(data)
        : createPollutionCheck(data));
      await modalApi.close();
      emit('success');
      message.success($t('ui.actionMessage.operationSuccess'));
    } finally {
      modalApi.unlock();
    }
  },
  async onOpenChange(isOpen: boolean) {
    if (!isOpen) {
      formType.value = 'create';
      aiSuggestion.value = null;
      return;
    }
    const data = modalApi.getData<{ formType: 'create' | 'update'; id?: number }>();
    formType.value = data.formType;
    // 重新挂载 schema 并注入 formApi，供"选择物料后回填名称/编码/规格"使用
    formApi.setState({ schema: useFormSchema(formApi) });
    if (!data.id) {
      return;
    }
    modalApi.lock();
    try {
      const row = await getPollutionCheck(data.id);
      // 仅待复核行允许编辑：回填基础字段
      await formApi.setValues(row);
    } finally {
      modalApi.unlock();
    }
  },
});
</script>

<template>
  <Modal :title="getTitle" class="w-2/3">
    <!-- AI 初筛区：未预览时是整宽大按钮，出结果后换成大字结论面板 -->
    <div class="mx-4 mb-4">
      <template v-if="!aiSuggestion">
        <Button
          block
          class="h-14 text-base hover:opacity-90"
          style="
            background: linear-gradient(135deg, #722ed1 0%, #1677ff 100%);
            border: none;
            color: #fff;
          "
          type="primary"
          :loading="previewing"
          @click="handlePrescreen"
        >
          <IconifyIcon class="mr-2 size-5" icon="lucide:sparkles" />
          一键 AI 初筛
        </Button>
        <p class="text-muted-foreground mt-2 text-center text-xs">
          按当前填写的物料信息给出污染初筛结论，仅供人工复核参考，不写入记录
        </p>
      </template>
      <div
        v-else
        class="ai-panel rounded-xl border-2 p-5 transition-opacity"
        :class="[aiTheme.bg, aiTheme.border, previewing ? 'opacity-60' : '']"
      >
        <div class="flex items-start gap-8">
          <div class="shrink-0">
            <div class="text-muted-foreground mb-1 text-xs">AI 初筛结论</div>
            <div class="text-3xl leading-none font-bold" :class="aiTheme.text">
              {{ aiResultText }}
            </div>
          </div>
          <div class="min-w-0 flex-1">
            <div class="text-muted-foreground mb-1 text-xs">
              置信度 {{ aiSuggestion.aiConfidence ?? '-' }}%
            </div>
            <div class="h-2 w-full overflow-hidden rounded-full bg-black/10">
              <div
                class="h-full rounded-full"
                :class="aiTheme.bar"
                :style="{ width: `${aiSuggestion.aiConfidence ?? 0}%` }"
              ></div>
            </div>
          </div>
          <Button size="small" :loading="previewing" @click="handlePrescreen">
            重新初筛
          </Button>
        </div>
        <div class="mt-4 space-y-1 text-sm">
          <div>
            <span class="font-medium">判定依据：</span>
            <span>{{ aiSuggestion.aiReason ?? '-' }}</span>
          </div>
          <div>
            <span class="font-medium">法规依据：</span>
            <span>{{ aiSuggestion.aiBasis ?? '-' }}</span>
          </div>
          <div>
            <span class="font-medium">推荐存储方法：</span>
            <span>{{ aiSuggestion.suggestedStorage ?? '-' }}</span>
          </div>
        </div>
        <div
          class="mt-3 rounded-lg bg-black/5 px-3 py-2 text-sm"
          :class="aiTheme.text"
        >
          {{ aiAdvice }}
        </div>
      </div>
    </div>
    <Form class="mx-4" />
  </Modal>
</template>

<style scoped>
/* 初筛结果入场：让用户第一时间注意到 AI 刚给出的结论 */
.ai-panel {
  animation: ai-panel-in 0.3s ease-out;
}

@keyframes ai-panel-in {
  from {
    opacity: 0;
    transform: translateY(-4px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
