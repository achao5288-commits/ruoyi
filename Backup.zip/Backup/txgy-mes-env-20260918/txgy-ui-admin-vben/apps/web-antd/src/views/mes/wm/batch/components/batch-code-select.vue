<script lang="ts" setup>
import { computed, ref, useAttrs, watchEffect } from 'vue';

import { Select } from 'ant-design-vue';

import { getBatchPage } from '#/api/mes/wm/batch';

defineOptions({ name: 'WmBatchCodeSelect', inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    allowClear?: boolean;
    disabled?: boolean;
    /** 按物料编码过滤：传了则只列出该物料的批次 */
    itemCode?: string;
    /** 选中值：批次号文本（对应 VARCHAR 批次号字段，非批次 ID） */
    modelValue?: string;
    placeholder?: string;
  }>(),
  {
    allowClear: true,
    disabled: false,
    itemCode: undefined,
    modelValue: undefined,
    placeholder: '请选择批次号',
  },
);

const emit = defineEmits<{
  change: [value: string | undefined];
  'update:modelValue': [value: string | undefined];
}>();

const attrs = useAttrs();
const allList = ref<
  { code: string; itemCode?: string; itemName?: string }[]
>([]);

const options = computed(() =>
  allList.value
    .filter((item) => !props.itemCode || item.itemCode === props.itemCode)
    .map((item) => ({
      label: item.itemName ? `${item.code}｜${item.itemName}` : item.code,
      value: item.code,
    })),
);

const selectValue = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val),
});

function handleChange(val: any) {
  emit('change', val);
}

function filterOption(input: string, option: any) {
  return String(option?.label ?? '')
    .toLowerCase()
    .includes(input.toLowerCase());
}

/** 加载批次下拉：label 展示「批次号｜物料名」，value 取批次号文本 */
watchEffect(async () => {
  const page = await getBatchPage({ pageNo: 1, pageSize: 100 });
  allList.value = (page?.list ?? [])
    .filter((item) => item.code)
    .map((item) => ({
      code: item.code!,
      itemCode: item.itemCode,
      itemName: item.itemName,
    }));
});
</script>

<template>
  <Select
    v-bind="attrs"
    v-model:value="selectValue"
    :allow-clear="allowClear"
    class="!w-full"
    :disabled="disabled"
    :filter-option="filterOption"
    :options="options"
    :placeholder="placeholder"
    show-search
    @change="handleChange"
  />
</template>
