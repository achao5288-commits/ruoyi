<script lang="ts" setup>
import { computed, ref, useAttrs, watchEffect } from 'vue';

import { Select } from 'ant-design-vue';

import { getWarehouseLocationSimpleList } from '#/api/mes/wm/warehouse/location';

defineOptions({ name: 'WmLocationPathSelect', inheritAttrs: false });

const props = withDefaults(
  defineProps<{
    allowClear?: boolean;
    disabled?: boolean;
    /** 选中值：`仓库名·库区名` 文本（对应 VARCHAR 存储位置字段，非 ID） */
    modelValue?: string;
    placeholder?: string;
  }>(),
  {
    allowClear: true,
    disabled: false,
    modelValue: undefined,
    placeholder: '请选择去向/库位',
  },
);

const emit = defineEmits<{
  change: [value: string | undefined];
  'update:modelValue': [value: string | undefined];
}>();

const attrs = useAttrs();
const options = ref<{ label: string; value: string }[]>([]);

const selectValue = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val),
});

function handleChange(val: any) {
  emit('change', val);
}

function filterOption(input: string, option: any) {
  return String(option?.value ?? '')
    .toLowerCase()
    .includes(input.toLowerCase());
}

/** 加载"仓库·库区"扁平选项（simple-list 一次取全，响应含 warehouseName） */
watchEffect(async () => {
  const list = await getWarehouseLocationSimpleList();
  options.value = (list ?? [])
    .filter((item) => item.name)
    .map((item) => {
      const label = item.warehouseName
        ? `${item.warehouseName}·${item.name}`
        : (item.name as string);
      return { label, value: label };
    });
});
</script>

<template>
  <Select
    v-bind="attrs"
    v-model:value="selectValue"
    :allow-clear="allowClear"
    class="!w-full"
    :disabled="disabled"
    :filter-option="filterOption"
    :options="options"
    :placeholder="placeholder"
    show-search
    @change="handleChange"
  />
</template>
