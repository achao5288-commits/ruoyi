import type { VbenFormSchema } from '#/adapter/form';
import type { VxeTableGridOptions } from '#/adapter/vxe-table';
import type { MesSetHazardousWasteApi } from '#/api/mes/safetyEnv/hazardousWaste';

/** 状态阶段选项 */
export const STAGE_OPTIONS = [
  { label: '已产生', value: 'GENERATED' },
  { label: '已入库暂存', value: 'STORED' },
  { label: '已转移', value: 'TRANSFERRED' },
  { label: '已处置', value: 'DISPOSED' },
];

/** 状态阶段文案 */
export const STAGE_MAP: Record<string, string> = Object.fromEntries(
  STAGE_OPTIONS.map((item) => [item.value, item.label]),
);

/** 状态阶段展示(色值用于 tag) */
export const STAGE_TAG_MAP: Record<string, { text: string; color: string }> = {
  GENERATED: { text: '已产生', color: 'default' },
  STORED: { text: '已入库暂存', color: 'processing' },
  TRANSFERRED: { text: '已转移', color: 'warning' },
  DISPOSED: { text: '已处置', color: 'success' },
};

/** 审核状态选项 */
export const STATUS_OPTIONS = [
  { label: '草稿', value: 'DRAFT' },
  { label: '已审核', value: 'APPROVED' },
  { label: '已驳回', value: 'REJECTED' },
];

/** 审核状态展示 */
export const STATUS_TAG_MAP: Record<string, { text: string; color: string }> = {
  DRAFT: { text: '草稿', color: 'default' },
  APPROVED: { text: '已审核', color: 'success' },
  REJECTED: { text: '已驳回', color: 'error' },
};

/** 数量单位选项 */
export const QUANTITY_UNIT_OPTIONS = [
  { label: '千克', value: 'kg' },
  { label: '吨', value: 't' },
  { label: '升', value: 'L' },
  { label: '个', value: '个' },
];

/** 常见危废代码选项（HJ 1276-2022 / 国家危废目录） */
export const WASTE_CODE_OPTIONS = [
  { label: 'HW08 废矿物油与含矿物油废物', value: 'HW08' },
  { label: 'HW09 油/水、烃/水混合物或乳化液', value: 'HW09' },
  { label: 'HW12 染料、涂料废物', value: 'HW12' },
  { label: 'HW13 有机树脂类废物', value: 'HW13' },
  { label: 'HW16 感光材料废物', value: 'HW16' },
  { label: 'HW17 表面处理废物', value: 'HW17' },
  { label: 'HW49 其他废物(废活性炭/空桶等)', value: 'HW49' },
];

/** 新增/修改危废台账的表单 */
export function useFormSchema(): VbenFormSchema[] {
  return [
    {
      fieldName: 'id',
      component: 'Input',
      dependencies: {
        triggerFields: [''],
        show: () => false,
      },
    },
    {
      fieldName: 'manifestNo',
      label: '转移联单编号',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '如：HW-2026-0001',
      },
      rules: 'required',
    },
    {
      fieldName: 'wasteCode',
      label: '危废代码',
      component: 'Select',
      componentProps: {
        options: WASTE_CODE_OPTIONS,
        showSearch: true,
        allowClear: true,
        placeholder: '请选择危废代码',
      },
      rules: 'required',
    },
    {
      fieldName: 'wasteName',
      label: '危废名称',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '如：废活性炭 / 废矿物油 / 涂料残渣',
      },
      rules: 'required',
    },
    {
      fieldName: 'quantity',
      label: '数量',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        step: 0.1,
        precision: 3,
        placeholder: '请输入数量',
      },
    },
    {
      fieldName: 'quantityUnit',
      label: '数量单位',
      component: 'Select',
      componentProps: {
        options: QUANTITY_UNIT_OPTIONS,
        allowClear: true,
        placeholder: '请选择单位',
      },
    },
    {
      fieldName: 'stage',
      label: '状态阶段',
      component: 'Select',
      componentProps: {
        options: STAGE_OPTIONS,
        allowClear: true,
        placeholder: '请选择阶段',
      },
    },
    {
      fieldName: 'storageLocation',
      label: '储存地点',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '如：危废暂存间 A-01',
      },
    },
    {
      fieldName: 'counterparty',
      label: '接收方/处置方',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '转移联单接收单位/处置单位名称',
      },
    },
    {
      fieldName: 'woId',
      label: '关联工单编号',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        placeholder: '关联的生产工单 id',
      },
    },
    {
      fieldName: 'handler',
      label: '处理人',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '请输入处理人',
      },
    },
    {
      fieldName: 'handleTime',
      label: '处理时间',
      component: 'DatePicker',
      componentProps: {
        showTime: true,
        valueFormat: 'YYYY-MM-DD HH:mm:ss',
        placeholder: '请选择处理时间',
      },
    },
    {
      fieldName: 'status',
      label: '审核状态',
      component: 'Select',
      componentProps: {
        options: STATUS_OPTIONS,
        allowClear: true,
        placeholder: '请选择审核状态',
      },
    },
    {
      fieldName: 'remark',
      label: '备注',
      component: 'Textarea',
      componentProps: {
        placeholder: '请输入备注',
        rows: 2,
      },
      formItemClass: 'col-span-3',
    },
  ];
}

/** 列表的搜索表单 */
export function useGridFormSchema(): VbenFormSchema[] {
  return [
    {
      fieldName: 'wasteCode',
      label: '危废代码',
      component: 'Select',
      componentProps: {
        allowClear: true,
        options: WASTE_CODE_OPTIONS,
        showSearch: true,
        placeholder: '请选择危废代码',
      },
    },
    {
      fieldName: 'wasteName',
      label: '危废名称',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '危废名称模糊',
      },
    },
    {
      fieldName: 'stage',
      label: '状态阶段',
      component: 'Select',
      componentProps: {
        allowClear: true,
        options: STAGE_OPTIONS,
        placeholder: '请选择阶段',
      },
    },
    {
      fieldName: 'status',
      label: '审核状态',
      component: 'Select',
      componentProps: {
        allowClear: true,
        options: STATUS_OPTIONS,
        placeholder: '请选择状态',
      },
    },
  ];
}

/** 列表的字段 */
export function useGridColumns(): VxeTableGridOptions<MesSetHazardousWasteApi.HazardousWaste>['columns'] {
  return [
    { field: 'manifestNo', title: '转移联单编号', minWidth: 180 },
    { field: 'wasteCode', title: '危废代码', width: 130 },
    { field: 'wasteName', title: '危废名称', minWidth: 150 },
    { field: 'quantity', title: '数量', width: 100, formatter: ({ cellValue }) => (cellValue != null ? `${cellValue}` : '-') },
    { field: 'quantityUnit', title: '单位', width: 80 },
    { field: 'stage', title: '状态阶段', width: 120, slots: { default: 'stage' } },
    { field: 'storageLocation', title: '储存地点', minWidth: 140, showOverflow: true },
    { field: 'counterparty', title: '接收方/处置方', minWidth: 160, showOverflow: true },
    { field: 'handler', title: '处理人', width: 100 },
    { field: 'handleTime', title: '处理时间', width: 170, formatter: 'formatDateTime' },
    { field: 'status', title: '审核状态', width: 100, slots: { default: 'status' } },
    { field: 'remark', title: '备注', minWidth: 150, showOverflow: true },
    { field: 'createTime', title: '创建时间', width: 170, formatter: 'formatDateTime' },
    {
      title: '操作',
      width: 160,
      fixed: 'right',
      slots: {
        default: 'actions',
      },
    },
  ];
}
