import type { VbenFormSchema } from '#/adapter/form';
import type { VxeTableGridOptions } from '#/adapter/vxe-table';
import type { MesSetFacilityApi } from '#/api/mes/safetyEnv/facility';

/** 设施类型选项 */
export const FACILITY_TYPE_OPTIONS = [
  { label: '活性炭吸附', value: 'ACTIVATED_CARBON' },
  { label: '催化燃烧', value: 'CATALYTIC_COMBUSTION' },
  { label: '袋式除尘', value: 'BAG_DUST' },
  { label: '废水处理', value: 'WATER_TREATMENT' },
  { label: '其他', value: 'OTHER' },
];

/** 设施类型文案 */
export const FACILITY_TYPE_MAP: Record<string, string> = Object.fromEntries(
  FACILITY_TYPE_OPTIONS.map((item) => [item.value, item.label]),
);

/** 运行状态选项 */
export const STATUS_OPTIONS = [
  { label: '运行', value: 'RUNNING' },
  { label: '停运', value: 'SHUTDOWN' },
  { label: '维护', value: 'MAINTENANCE' },
];

/** 运行状态展示(色值用于 tag) */
export const STATUS_TAG_MAP: Record<string, { text: string; color: string }> = {
  RUNNING: { text: '运行', color: 'success' },
  SHUTDOWN: { text: '停运', color: 'default' },
  MAINTENANCE: { text: '维护', color: 'warning' },
};

/** 新增/修改治污设施台账的表单 */
export function useFormSchema(): VbenFormSchema[] {
  return [
    {
      fieldName: 'id',
      component: 'Input',
      dependencies: {
        triggerFields: [''],
        show: () => false,
      },
    },
    {
      fieldName: 'code',
      label: '设施编号',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '如：FAC-001',
      },
      rules: 'required',
    },
    {
      fieldName: 'name',
      label: '设施名称',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '如：液体喷漆废气活性炭吸附塔',
      },
      rules: 'required',
    },
    {
      fieldName: 'facilityType',
      label: '设施类型',
      component: 'Select',
      componentProps: {
        options: FACILITY_TYPE_OPTIONS,
        allowClear: true,
        placeholder: '请选择设施类型',
      },
    },
    {
      fieldName: 'outletCode',
      label: '对应排放口编号',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '对应排污许可证排放口编号',
      },
    },
    {
      fieldName: 'designCapacity',
      label: '设计处理能力',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '如：5000 m³/h',
      },
    },
    {
      fieldName: 'carbonLoad',
      label: '活性炭填充量(kg)',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        step: 1,
        precision: 2,
        placeholder: '活性炭填充量',
      },
    },
    {
      fieldName: 'carbonCycleDays',
      label: '更换周期(天)',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        step: 1,
        placeholder: '活性炭更换周期',
      },
    },
    {
      fieldName: 'lastCarbonTime',
      label: '最近换炭时间',
      component: 'DatePicker',
      componentProps: {
        showTime: true,
        valueFormat: 'YYYY-MM-DD HH:mm:ss',
        placeholder: '请选择最近一次换炭时间',
      },
    },
    {
      fieldName: 'wasteLocation',
      label: '废活性炭去向',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '如：危废暂存间 A-01',
      },
    },
    {
      fieldName: 'machineryId',
      label: '关联设备编号',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        placeholder: '设备档案 id',
      },
    },
    {
      fieldName: 'workshopId',
      label: '所在车间编号',
      component: 'InputNumber',
      componentProps: {
        min: 0,
        placeholder: '车间 id',
      },
    },
    {
      fieldName: 'status',
      label: '运行状态',
      component: 'Select',
      componentProps: {
        options: STATUS_OPTIONS,
        allowClear: true,
        placeholder: '请选择状态',
      },
    },
    {
      fieldName: 'photoUrl',
      label: '设施照片 URL',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '设施照片地址',
      },
    },
    {
      fieldName: 'remark',
      label: '备注',
      component: 'Textarea',
      componentProps: {
        placeholder: '请输入备注',
        rows: 2,
      },
      formItemClass: 'col-span-3',
    },
  ];
}

/** 列表的搜索表单 */
export function useGridFormSchema(): VbenFormSchema[] {
  return [
    {
      fieldName: 'code',
      label: '设施编号',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '设施编号',
      },
    },
    {
      fieldName: 'name',
      label: '设施名称',
      component: 'Input',
      componentProps: {
        allowClear: true,
        placeholder: '设施名称模糊',
      },
    },
    {
      fieldName: 'facilityType',
      label: '设施类型',
      component: 'Select',
      componentProps: {
        allowClear: true,
        options: FACILITY_TYPE_OPTIONS,
        placeholder: '请选择类型',
      },
    },
    {
      fieldName: 'status',
      label: '运行状态',
      component: 'Select',
      componentProps: {
        allowClear: true,
        options: STATUS_OPTIONS,
        placeholder: '请选择状态',
      },
    },
  ];
}

/** 列表的字段 */
export function useGridColumns(): VxeTableGridOptions<MesSetFacilityApi.Facility>['columns'] {
  return [
    { field: 'code', title: '设施编号', minWidth: 120 },
    { field: 'name', title: '设施名称', minWidth: 200, showOverflow: true },
    { field: 'facilityType', title: '设施类型', width: 120, formatter: ({ cellValue }) => (cellValue ? (FACILITY_TYPE_MAP[cellValue] ?? cellValue) : '-') },
    { field: 'outletCode', title: '排放口编号', width: 120 },
    { field: 'designCapacity', title: '设计处理能力', minWidth: 140, showOverflow: true },
    { field: 'carbonLoad', title: '活性炭填充量', width: 120, formatter: ({ cellValue }) => (cellValue != null ? `${cellValue} kg` : '-') },
    { field: 'carbonCycleDays', title: '更换周期', width: 100, formatter: ({ cellValue }) => (cellValue != null ? `${cellValue} 天` : '-') },
    { field: 'lastCarbonTime', title: '最近换炭时间', width: 170, formatter: 'formatDateTime' },
    { field: 'wasteLocation', title: '废活性炭去向', minWidth: 140, showOverflow: true },
    { field: 'status', title: '运行状态', width: 100, slots: { default: 'status' } },
    { field: 'remark', title: '备注', minWidth: 150, showOverflow: true },
    { field: 'createTime', title: '创建时间', width: 170, formatter: 'formatDateTime' },
    {
      title: '操作',
      width: 160,
      fixed: 'right',
      slots: {
        default: 'actions',
      },
    },
  ];
}
